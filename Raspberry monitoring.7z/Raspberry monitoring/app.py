from flask import Flask, render_template, jsonify, request, send_file, send_from_directory, session, redirect, url_for, flash
from flask_caching import Cache
from apscheduler.schedulers.background import BackgroundScheduler
from tkinter.filedialog import asksaveasfile
import openpyxl
import json
import paramiko
import mysql.connector
import sqlite3
import pandas as pd
from datetime import datetime, timedelta
import io
from ldap3 import Server, Connection, ALL
from functools import wraps


app = Flask(__name__, static_url_path='/static')

# Cache konfiguráció Redis alapú cache használatával
cache = Cache(app, config={
    'CACHE_TYPE': 'RedisCache',
    'CACHE_REDIS_HOST': 'localhost',
    'CACHE_REDIS_PORT': 6379,
    'CACHE_REDIS_DB': 0,
    'CACHE_DEFAULT_TIMEOUT': 24 * 60 * 60  # 24 órás timeout
})

# Engedélyezett oldalak a különböző szerepkörök számára
PERMISSIONS = {
    "Manager": ["users_controller_formanagers", "pn_progress", "users_progress"],
    "Teamleader": ["teamleaders"],
    "IT": "all"  # IT mindent elér
}

def role_required(*allowed_roles):
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if 'user' not in session:
                flash("Ehhez be kell jelentkezned!", "danger")
                return redirect(url_for('login'))
                
            user_role = session['user'].get('job_title', '').strip().upper()
            if not any(role in user_role for role in allowed_roles):
                flash("Nincs jogosultsagod ehhez az oldalhoz!", "danger")
                return redirect(request.referrer or url_for('index'))  #
                
            return f(*args, **kwargs)
        return decorated_function
    return decorator





@app.route('/static/<path:filename>')
def static_files(filename):
    return send_from_directory('static', filename)

# SQLite connection
def get_sqlite_connection():
    return sqlite3.connect(r'/mnt/sqlite_db/test_db.db')

# MySQL connection
def get_mysql_connection():
    return mysql.connector.connect(
        host='10.10.2.15',
        user='root',
        password='admin321',
        database='paperless'
    )

# Adatok olvasÃ¡sa a JSON fÃ¡jlbÃ³l (ahol a Raspberry Pi adatok tÃ¡rolÃ³dnak)

def load_data():

    with open('data/devices.json') as f:

        return json.load(f)



# SSH parancs vÃ©grehajtÃ¡sa a Raspberry Pi-n

def execute_command_on_pi(ip, username, password, command):

    try:

        client = paramiko.SSHClient()

        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

        client.connect(ip, username=username, password=password)

        stdin, stdout, stderr = client.exec_command(command)



        stdout_output = stdout.read().decode().strip()

        stderr_output = stderr.read().decode().strip()



        client.close()



        if stderr_output:

            # If there's any error message, include it in the response

            return f"Error: {stderr_output}"

        return stdout_output

    except Exception as e:

        return f"Error: {e}"



# Function to check virtual environment and packages

def check_virtualenv_and_packages_on_pi(ip, username, password):

    username = "user"

    password = "user"

    command = """

    if [ ! -d "/home/user/myenv" ]; then

        # If the virtual environment does not exist, create and install packages

        python3 -m venv /home/user/myenv

        source /home/user/myenv/bin/activate

        pip install ttkbootstrap mysql-connector Pillow

        pip install netifaces

        echo "Installed"

    else

        # Check if the packages are already installed

        source /home/user/myenv/bin/activate

        if pip show ttkbootstrap && pip show mysql-connector && pip show Pillow; then

            echo "Installed"

        else

            echo "Not Installed"

        fi

    fi

    """

    result = execute_command_on_pi(ip, username, password, command)

    return result



# API vÃ©gpont a fÃ¡jl letÃ¶ltÃ©sÃ©hez Ã©s ellenÅ‘rzÃ©shez

@app.route('/api/download_file', methods=['POST'])

def download_file():

    ip = request.json['ip']

    username = "user"  # Default username

    password = "user"  # Default password

    

    # Check and install necessary virtual environment and packages

    result = check_virtualenv_and_packages_on_pi(ip, username, password)

    

    # Check the result of installation or verification

    if "Installed" in result:

        return jsonify({"result": "Packages installed and verified successfully."})

    elif "Not Installed" in result:

        return jsonify({"result": "Failed to install packages, please check manually."})

    else:

        return jsonify({"result": result})  # Return any other potential output or error




def manager_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user' not in session or session['user'].get('job_title') != 'Manager':
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function



# Programok Ã¡llapotÃ¡nak ellenÅ‘rzÃ©se oldal
@app.route('/programs')
@role_required("IT")  # Csak az IT csoport érheti el
def programs():
    return render_template('programs.html', user=session.get('user'))


@app.route('/')
@role_required("IT")  # Csak az IT csoport érheti el az index oldalt
def index():
    return render_template('index.html', user=session.get('user'))


# API vÃ©gpont a Raspberry Pi adatokhoz
@app.route('/api/devices')

def devices_api():

    data = load_data()

    return jsonify(data)



# API vÃ©gpont a program indÃ­tÃ¡sÃ¡hoz

@app.route('/api/start_program', methods=['POST'])

def start_program():

    ip = request.json['ip']

    username = "user"  # Default username

    password = "user"  # Default password

    command = f"/bin/bash -c 'source /home/user/myenv/bin/activate && nohup python /home/user/Desktop/V3.7.py > /home/user/program_output.log 2>&1 &'"

    

    # SSH command to start the program

    result = execute_command_on_pi(ip, username, password, command)

    

    # Check the program log after starting

    check_command = "cat /home/user/program_output.log"

    output = execute_command_on_pi(ip, username, password, check_command)

    return jsonify({"result": f"Program started on {ip}", "log_output": output})





# API vÃ©gpont a program leÃ¡llÃ­tÃ¡sÃ¡hoz

@app.route('/api/stop_program', methods=['POST'])

def stop_program_api():

    ip = request.json['ip']

    username = "user"  # Default username

    password = "user"  # Default password

    

    # SSH command to stop the program

    command = "pkill -f V3.7.py"

    result = execute_command_on_pi(ip, username, password, command)

    return jsonify({"result": f"Program stopped on {ip}", "output": result})





#error html
@app.route('/errors_controller')
@role_required("IT")  # Csak az IT csoport érheti el
def errors_controller():
    return render_template('errors_controller.html', user=session.get('user'))





@app.route('/api/errors_data')

def errors_data():

    conn = get_db_connection()

    cursor = conn.cursor()

    query = "SELECT ID, `Device IP`, `Device Name`, Error, `Error Raised Date`, `Error Solved Date`, `Error Status` FROM errors"

    cursor.execute(query)

    rows = cursor.fetchall()

    cursor.close()

    conn.close()



    # EllenÅ‘rizd, hogy az oszlopnevek helyesek-e

    columns = ['ID', 'Device IP', 'Device Name', 'Error', 'Error Raised Date', 'Error Solved Date', 'Error Status']

    data = [dict(zip(columns, row)) for row in rows]

    return jsonify(data)



# FrissÃ­tÃ©s az 'errors' tÃ¡blÃ¡ban az ID alapjÃ¡n

@app.route('/api/resolve_error', methods=['POST'])

def resolve_error():

    error_id = request.json['id']

    current_date = datetime.now().strftime('%Y-%m-%d %H:%M:%S')



    conn = get_db_connection()

    cursor = conn.cursor()



    query = """

        UPDATE errors 

        SET `Error Solved Date` = %s, `Error Status` = 'Completed' 

        WHERE ID = %s

    """

    cursor.execute(query, (current_date, error_id))

    conn.commit()

    cursor.close()

    conn.close()



    return jsonify({"result": "Error resolved successfully."})



# Rekord tÃ¶rlÃ©se az 'errors' tÃ¡blÃ¡bÃ³l az ID alapjÃ¡n

@app.route('/api/delete_error', methods=['POST'])

def delete_error():

    error_id = request.json['id']



    conn = get_db_connection()

    cursor = conn.cursor()



    query = "DELETE FROM errors WHERE ID = %s"

    cursor.execute(query, (error_id,))

    conn.commit()

    cursor.close()

    conn.close()



    return jsonify({"result": "Error deleted successfully."})



# API vÃ©gpont a parancsok futtatÃ¡sÃ¡hoz

@app.route('/api/run_command', methods=['POST'])

def run_command():

    ip = request.json['ip']

    command_type = request.json['command']  # 'Restart' or 'Update'

    username = "user"  # Default username

    password = "user"  # Default password



    if command_type == "Restart":

        # 1. Stop the program

        stop_command = "pkill -f V3.7.py"

        stop_result = execute_command_on_pi(ip, username, password, stop_command)



        # 2. Restart the program

        start_command = f"/bin/bash -c 'source /home/user/myenv/bin/activate && nohup python /home/user/Desktop/V3.7.py > /home/user/program_output.log 2>&1 &'"

        start_result = execute_command_on_pi(ip, username, password, start_command)

        

        return jsonify({"result": f"Program restarted on {ip}", "stop_output": stop_result, "start_output": start_result})



    elif command_type == "Update":

        # 1. Stop the program

        stop_command = "pkill -f V3.7.py"

        stop_result = execute_command_on_pi(ip, username, password, stop_command)



        # 2. Delete the virtual environment and the program

        delete_command = "rm -rf /home/user/myenv /home/user/Desktop/V3.7.py"

        delete_result = execute_command_on_pi(ip, username, password, delete_command)



        # 3. Reinstall the virtual environment and the program

        update_result = check_virtualenv_and_packages(ip, username, password)



        # 4. Restart the program

        start_command = f"/bin/bash -c 'source /home/user/myenv/bin/activate && nohup python /home/user/Desktop/V3.7.py > /home/user/program_output.log 2>&1 &'"

        start_result = execute_command_on_pi(ip, username, password, start_command)

        

        return jsonify({

            "result": f"Program updated and restarted on {ip}", 

            "stop_output": stop_result, 

            "delete_output": delete_result, 

            "update_output": update_result, 

            "start_output": start_result

        })







# API endpoint to update a user's record

@app.route('/api/update_user/<int:id>', methods=['POST'])

def update_user(id):

    data = request.json

    conn = get_db_connection()

    cursor = conn.cursor()

    query = """

    UPDATE workstationworkorder

    SET start_time = %s, end_time = %s, status = %s, process_id = %s, next_station_id = %s

    WHERE ID = %s

    """

    cursor.execute(query, (data['Start Time'], data['End Time'], data['Status'], data['Process ID'], data['Next Station ID'], id))

    conn.commit()

    cursor.close()

    conn.close()

    return jsonify({"message": "Record updated successfully"})



# API endpoint to delete a user's record

@app.route('/api/delete_user/<int:id>', methods=['DELETE'])

def delete_user(id):

    conn = get_db_connection()

    cursor = conn.cursor()

    query = "DELETE FROM workstationworkorder WHERE ID = %s"

    cursor.execute(query, (id,))

    conn.commit()

    cursor.close()

    conn.close()

    return jsonify({"message": "Record deleted successfully"})



# API endpoint to delete selected users

@app.route('/api/delete_selected', methods=['POST'])

def delete_selected_users():

    data = request.json

    ids = data['ids']  # Get the list of IDs to delete

    if not ids:

        return jsonify({"message": "No IDs provided"}), 400



    conn = get_db_connection()

    cursor = conn.cursor()

    query = "DELETE FROM workstationworkorder WHERE ID IN (%s)" % ','.join(['%s'] * len(ids))

    cursor.execute(query, ids)

    conn.commit()

    cursor.close()

    conn.close()



    return jsonify({"message": "Selected records deleted successfully"})



@app.route('/api/update_program', methods=['POST'])

def update_program():

    ip = request.json['ip']

    

    # Default credentials for Raspberry Pi devices

    username = "user"

    password = "user"

    

    # Stop the running program first

    stop_command = "pkill -f V3.7.py"

    stop_result = execute_command_on_pi(ip, username, password, stop_command)



    # Remove the existing environment and program files

    remove_command = "rm -rf /home/user/myenv /home/user/Desktop/V3.7.py"

    remove_result = execute_command_on_pi(ip, username, password, remove_command)



    # Reinstall the virtual environment and program

    reinstall_result = check_virtualenv_and_packages(ip, username, password)

    

    # Start the program after reinstalling

    start_command = "/bin/bash -c 'source /home/user/myenv/bin/activate && nohup python /home/user/Desktop/V3.7.py > /home/user/program_output.log 2>&1 &'"

    start_result = execute_command_on_pi(ip, username, password, start_command)



    return jsonify({"result": f"Program updated and restarted on {ip}", "stop_output": stop_result, "reinstall_output": reinstall_result, "start_output": start_result})





# MariaDB kapcsolat beÃ¡llÃ­tÃ¡sa

def get_db_connection():

    return mysql.connector.connect(

        host='10.10.2.15',

        database='paperless',

        user='root',

        password='admin321'

    )



# Adatok lekÃ©rdezÃ©se a tÃ¡blÃ¡bÃ³l

def fetch_data():
    conn = get_db_connection()
    cursor = conn.cursor()
    query = """
    SELECT 
        w.ID, 
        w.workstation_id, 
        w.device_id, 
        wo.name AS worker_name, 
        CONCAT('WO: ', wo2.WO, ', PN: ', wo2.PN, '') AS work_order_data, 
        w.start_time,
        w.end_time,
        w.status,
        w.process_id,
        w.next_station_id,
        w.qty  
    FROM 
        workstationworkorder w
    LEFT JOIN 
        workers wo ON w.worker_id = wo.ID
    LEFT JOIN 
        workorders wo2 ON w.work_id = wo2.id
    """
    cursor.execute(query)
    
    columns = [col[0] for col in cursor.description]
    
    rows = [dict(zip(columns, row)) for row in cursor.fetchall()]  # ?? Ez a kritikus sor
    
    cursor.close()
    conn.close()

    formatted_rows = []
    for row in rows:
        if row["status"] == "Active":
            display_status = f"Jelenleg itt van: {row['process_id']}"
            status_class = "status-current"
            status_icon = "fa-check-circle"
        else:
            display_status = f"Ide lett kldve: {row['next_station_id']}"
            status_class = "status-sent"
            status_icon = "fa-arrow-right"

        formatted_rows.append({
            "ID": row["ID"],
            "worker_name": row["worker_name"],
            "work_order_data": row["work_order_data"],
            "start_time": row["start_time"],
            "end_time": row["end_time"] if row["end_time"] else "",
            "status": display_status,
            "status_class": status_class,
            "status_icon": status_icon,
            "qty": row["qty"],
        })

    return formatted_rows[::-1]















@app.route('/users_controller')
@role_required("IT")  # Csak az IT csoport érheti el
def users_controller():

    columns = ['ID', 'Workstation ID', 'Device ID', 'Worker Name', 'Work Order Data', 'Start Time', 'End Time', 'Status', 'Process ID', 'Next Station ID', 'QTY']

    rows = fetch_data()

    return render_template('users_controller.html', columns=columns, rows=rows, user=session.get('user'))



@app.route('/api/users_data')

def users_data():

    rows = fetch_data()

    columns = ['ID', 'Workstation ID', 'Device ID', 'Worker Name', 'Work Order Data', 'Start Time', 'End Time', 'Status', 'Process ID', 'Next Station ID', 'QTY']

    

    data = [dict(zip(columns, row)) for row in rows]

    return jsonify(data)













@app.route('/users_controller_formanagers')
@role_required("IT")
def users_controller_formanagers():
    return render_template('user_controller_formanagers.html', user=session.get('user'))

@app.route('/pn_progress')
@role_required("IT")
def pn_progress():
    return render_template('pn_progress.html', user=session.get('user'))
    
@app.route('/users_progress')
@role_required("MANAGER", "IT")
def users_progress():
    return render_template('users_progress.html', user=session.get('user'))
    


@app.route('/api/users_progress', methods=['GET'])
def users_progress_data():
    conn = get_mysql_connection()
    cursor = conn.cursor(dictionary=True)

    selected_date = request.args.get('date')
    if not selected_date:
        return jsonify({"error": "No date provided. Please select a date."}), 400

    print(f"[DEBUG] Selected date: {selected_date}")

    try:
        # All time query
        all_time_query = """
            SELECT w.name AS user,
                   TIMESTAMPDIFF(
                       SECOND,
                       MIN(ws.login_date),
                       MAX(CASE
                           WHEN DATE(ws.logout_date) = %s THEN ws.logout_date
                           ELSE NULL
                       END)
                   ) AS duration
            FROM workers w
            LEFT JOIN workerworkstation ws ON w.ID = ws.worker_id
            WHERE DATE(ws.login_date) = %s
            GROUP BY w.name
        """
        cursor.execute(all_time_query, (selected_date, selected_date))
        all_time_results = cursor.fetchall()
        all_time_dict = {row['user']: row['duration'] or 0 for row in all_time_results}
        print(f"[DEBUG] All Time Dict: {all_time_dict}")

        # Effective time query
        effective_time_query = """
            SELECT
                w.name AS user,
                SUM(
                    CASE
                        WHEN DATE(ww.start_time) = %s AND DATE(ww.end_time) = %s THEN
                            TIMESTAMPDIFF(SECOND,
                                GREATEST(ww.start_time, CONCAT(%s, ' 00:00:00')),
                                LEAST(ww.end_time, CONCAT(%s, ' 23:59:59'))
                            )
                        ELSE 0
                    END
                ) AS effective_time,
                COUNT(DISTINCT ww.id) AS total_wo
            FROM workers w
            LEFT JOIN workstationworkorder ww ON w.ID = ww.worker_id
            WHERE ww.status = 'Completed'
            AND DATE(ww.start_time) = %s
            GROUP BY w.name
        """

        cursor.execute(effective_time_query, (selected_date, selected_date, selected_date, selected_date, selected_date))
        effective_time_results = cursor.fetchall()




        for row in effective_time_results:
            print(f"[DEBUG] User: {row['user']}")

        # Combine results
        results = []
        for row in effective_time_results:
            user = row['user']
            effective_time = row.get('effective_time', 0)
            total_wo = row.get('total_wo', 0)
            all_time = all_time_dict.get(user, 0)

            # Ensure Effective Time does not exceed All Time
            if effective_time > all_time:
                effective_time = all_time

            # Calculate Loss/Waited Time
            loss_waited = max(all_time - effective_time, 0)

            results.append({
                'user': user,
                'effective_time': format_time_difference(effective_time),
                'all_time': format_time_difference(all_time),
                'loss_waited': format_time_difference(loss_waited),
                'total_wo': total_wo
            })


        print(f"[DEBUG] Final Combined Results: {results}")
        return jsonify(results)

    except Exception as e:
        print(f"[ERROR] Error processing users_progress_data: {e}")
        return jsonify({"error": str(e)}), 500

    finally:
        cursor.close()
        conn.close()


from io import BytesIO
from flask import send_file

def seconds_to_hms(seconds):
    """Convert seconds to a string in hh:mm:ss format."""
    if not seconds or seconds == 0:
        return "0 hours 0 minutes 0 seconds"
    hours = seconds // 3600
    minutes = (seconds % 3600) // 60
    secs = seconds % 60
    return f"{hours} hours {minutes} minutes {secs} seconds"

def adjust_column_width(ws):
    """Adjust the width of Excel columns based on the longest text in each column."""
    for col in ws.columns:
        max_length = 0
        col_letter = col[0].column_letter  # Get the column letter (A, B, etc.)
        for cell in col:
            try:  # Ignore any empty cells
                if cell.value:
                    max_length = max(max_length, len(str(cell.value)))
            except Exception as e:
                print(f"[DEBUG] Error calculating column width: {e}")
        adjusted_width = max_length + 2  # Add padding for readability
        ws.column_dimensions[col_letter].width = adjusted_width




def safe_float(value):
    """Biztonságos float konverzió: ha None vagy üres string, akkor 0.0"""
    try:
        return float(value) if value not in [None, '', ' '] else 0.0
    except ValueError:
        return 0.0

def safe_datetime(value):
    """Biztonságos datetime konverzió: ha None vagy üres string, akkor None"""
    try:
        return datetime.strptime(value, "%Y-%m-%d %H:%M:%S") if value else None
    except ValueError:
        return None

def seconds_to_hour_decimal(seconds):
    if seconds is None or seconds == 0:
        return "0.00"
    
    hours = seconds // 3600
    minutes = (seconds % 3600) / 60  
    return f"{hours + (minutes / 60):.2f}"  
    
def adjust_column_width(ws):
    for col in ws.columns:
        max_length = 0
        col_letter = col[0].column_letter  # Az oszlop betuje
        for cell in col:
            try:
                if cell.value:
                    max_length = max(max_length, len(str(cell.value)))
            except:
                pass
        ws.column_dimensions[col_letter].width = max_length + 2     


@app.route('/api/users_progress_month', methods=['GET'])
def users_progress_month():
    conn = get_mysql_connection()
    cursor = conn.cursor(dictionary=True)

    year = request.args.get('year')
    month = request.args.get('month')

    if not year or not month:
        return jsonify({"error": "Year and month must be provided."}), 400

    try:
        month_start = datetime(int(year), int(month), 1)
        next_month = (month_start.replace(day=28) + timedelta(days=4)).replace(day=1)
        month_end = next_month - timedelta(days=1)

        # 🔹 Effective time és WO adatok lekérdezése + Completed QTY oszlop
        effective_time_query = """
            SELECT 
                w.name AS user,
                wo.WO,
                wo.PN,
                ww.start_time,
                ww.end_time,
                ww.QTY AS completed_qty,  -- Új oszlop: Completed QTY
                TIMESTAMPDIFF(SECOND, GREATEST(ww.start_time, %s), LEAST(ww.end_time, %s)) AS effective_time
            FROM workers w
            LEFT JOIN workstationworkorder ww ON w.ID = ww.worker_id
            LEFT JOIN workorders wo ON ww.work_id = wo.ID
            WHERE ww.status = 'Completed' AND ww.start_time BETWEEN %s AND %s
        """
        cursor.execute(effective_time_query, (month_start, month_end, month_start, month_end))
        effective_time_results = cursor.fetchall()

        # 🔹 QTY és PROD lekérdezése `t_dump` táblából
        qty_prod_time_query = """
            SELECT 
                wo.PN, 
                wo.QTY, 
                td.PROD AS PROD_TIME
            FROM workorders wo
            LEFT JOIN t_dump td ON wo.PN = td.`PART.NBR`
        """
        cursor.execute(qty_prod_time_query)

        # Adatok eltárolása dictionary formában a gyors hozzáférés érdekében
        qty_prod_time_results = {
            row['PN']: {
                'QTY': safe_float(row['QTY']),  
                'PROD_TIME': safe_float(row['PROD_TIME'])
            } for row in cursor.fetchall()
        }


        # 🔹 Adatok csoportosítása felhasználók szerint
        users_data = {}

        for row in effective_time_results:
            user = row['user']
            PN = row['PN']
            start_time = safe_datetime(row['start_time'])
            end_time = safe_datetime(row['end_time'])
            effective_time = row.get('effective_time', 0)

            # 🔹 QTY és PROD_TIME konvertálása számokká
            qty = qty_prod_time_results.get(PN, {}).get('QTY', 0.0)
            prod_time = qty_prod_time_results.get(PN, {}).get('PROD_TIME', 0.0)
            completed_qty = safe_float(row['completed_qty'])  # Új Completed QTY érték

            # 🔹 Elvárt idő és eltelt idő kiszámítása
            expected_time = qty * prod_time * 3600  # Órából másodpercbe
            elapsed_time = (end_time - start_time).total_seconds() if end_time and start_time else 0
            difference = expected_time - elapsed_time

            if user not in users_data:
                users_data[user] = []

            users_data[user].append([
                row["WO"], PN, start_time, end_time, 
                qty, completed_qty, prod_time, seconds_to_hour_decimal(expected_time), 
                seconds_to_hour_decimal(elapsed_time), seconds_to_hour_decimal(difference)
            ])

        # 🔹 Excel fájl generálása több munkalappal
        output = BytesIO()
        wb = openpyxl.Workbook()

        for user, data in users_data.items():
            ws = wb.create_sheet(title=user[:31])  # Munkalap neve max. 31 karakter lehet

            headers = ["WO", "PN", "Start Time", "End Time", 
                       "QTY", "Completed QTY", "PROD.TIME", "Elvart ido (H.MM)", 
                       "Eltelt ido (H.MM)", "Különbség (H.MM)"]
            ws.append(headers)

            for row in data:
                ws.append(row)

            adjust_column_width(ws)  # Oszlopok szélességének beállítása

        # 🔹 Alapértelmezett munkalap törlése
        if "Sheet" in wb.sheetnames:
            wb.remove(wb["Sheet"])

        # 🔹 Excel fájl mentése memóriába
        wb.save(output)
        output.seek(0)

        filename = f"Users_Progress_Month_{year}_{month}.xlsx"
        return send_file(output, as_attachment=True, download_name=filename, mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')

    except Exception as e:
        print(f"[ERROR] Error processing users_progress_month: {e}")
        return jsonify({"error": str(e)}), 500

    finally:
        cursor.close()
        conn.close()

        
      


@app.route('/api/users_progress_day', methods=['GET'])
def users_progress_day():
    conn = get_mysql_connection()
    cursor = conn.cursor(dictionary=True)

    date = request.args.get('date')
    
    if not date:
        return jsonify({"error": "Date must be provided."}), 400

    try:
        day_start = datetime.strptime(date, "%Y-%m-%d")
        day_end = day_start + timedelta(days=1)

        # 🔹 Effective time és WO adatok lekérdezése
        effective_time_query = """
            SELECT 
                w.name AS user,
                wo.WO,
                wo.PN,
                ww.start_time,
                ww.end_time,
                ww.QTY AS completed_qty,  -- Új oszlop: Completed QTY
                TIMESTAMPDIFF(SECOND, GREATEST(ww.start_time, %s), LEAST(ww.end_time, %s)) AS effective_time
            FROM workers w
            LEFT JOIN workstationworkorder ww ON w.ID = ww.worker_id
            LEFT JOIN workorders wo ON ww.work_id = wo.ID
            WHERE ww.status = 'Completed' AND ww.start_time BETWEEN %s AND %s
        """
        cursor.execute(effective_time_query, (day_start, day_end, day_start, day_end))
        effective_time_results = cursor.fetchall()

        # 🔹 QTY és PROD lekérdezése `t_dump` táblából
        qty_prod_time_query = """
            SELECT 
                wo.PN, 
                wo.QTY, 
                td.PROD AS PROD_TIME
            FROM workorders wo
            LEFT JOIN t_dump td ON wo.PN = td.`PART.NBR`
        """
        cursor.execute(qty_prod_time_query)

        # Adatok eltárolása dictionary formában a gyors hozzáférés érdekében
        qty_prod_time_results = {
            row['PN']: {
                'QTY': safe_float(row['QTY']),  
                'PROD_TIME': safe_float(row['PROD_TIME'])
            } for row in cursor.fetchall()
        }

        # 🔹 Adatok csoportosítása felhasználók szerint
        users_data = {}

        for row in effective_time_results:
            user = row['user']
            PN = row['PN']
            start_time = safe_datetime(row['start_time'])
            end_time = safe_datetime(row['end_time'])
            effective_time = row.get('effective_time', 0)

            # 🔹 QTY és PROD_TIME konvertálása számokká
            qty = qty_prod_time_results.get(PN, {}).get('QTY', 0.0)
            prod_time = qty_prod_time_results.get(PN, {}).get('PROD_TIME', 0.0)
            completed_qty = safe_float(row['completed_qty'])  # Új Completed QTY érték

            # 🔹 Elvárt idő és eltelt idő kiszámítása
            expected_time = qty * prod_time * 3600  # Órából másodpercbe
            elapsed_time = (end_time - start_time).total_seconds() if end_time and start_time else 0
            difference = expected_time - elapsed_time

            if user not in users_data:
                users_data[user] = []

            users_data[user].append([
                row["WO"], PN, start_time, end_time, effective_time,
                qty, completed_qty, prod_time, seconds_to_hour_decimal(expected_time), 
                seconds_to_hour_decimal(elapsed_time), seconds_to_hour_decimal(difference)
            ])

        # 🔹 Excel fájl generálása több munkalappal
        output = BytesIO()
        wb = openpyxl.Workbook()

        # **HIBA ELKERÜLÉSE: Ha nincs adat, hozzunk létre egy üres lapot**
        if not users_data:
            ws = wb.active
            ws.title = "No Data"
            ws.append(["Nincs adat a megadott dátumra"])
        else:
            for user, data in users_data.items():
                ws = wb.create_sheet(title=user[:31])  # Munkalap neve max. 31 karakter lehet

                headers = ["WO", "PN", "Start Time", "End Time", "Effective Time (H.MM)",
                        "QTY", "Completed QTY", "PROD.TIME", "Elvart ido (H.MM)", 
                        "Eltelt ido (H.MM)", "Különbség (H.MM)"]
                ws.append(headers)

                for row in data:
                    ws.append(row)

                adjust_column_width(ws)  # Oszlopok szélességének beállítása

        # 🔹 Alapértelmezett munkalap törlése, ha van másik
        if "Sheet" in wb.sheetnames and len(wb.sheetnames) > 1:
            wb.remove(wb["Sheet"])

        # 🔹 Excel fájl mentése memóriába
        wb.save(output)
        output.seek(0)

        filename = f"Users_Progress_Day_{date}.xlsx"
        return send_file(output, as_attachment=True, download_name=filename, mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')

    except Exception as e:
        print(f"[ERROR] Error processing users_progress_day: {e}")
        return jsonify({"error": str(e)}), 500

    finally:
        cursor.close()
        conn.close()











def format_time(seconds):
    if not seconds or seconds == 0:
        return "0 hours 0 minutes 0 seconds"
    hours = seconds // 3600
    minutes = (seconds % 3600) // 60
    secs = seconds % 60
    return f"{hours} hours {minutes} minutes {secs} seconds"

def format_time_difference(seconds):
    """Format time difference into hours, minutes, and seconds."""
    if seconds is None or seconds <= 0:
        return "0 hours 0 minutes 0 seconds"
    hours = int(seconds // 3600)
    minutes = int((seconds % 3600) // 60)
    seconds = int(seconds % 60)
    return f"{hours} hours {minutes} minutes {seconds} seconds"

















# Adatok cache-be töltése
def load_data_into_cache():
    print("Cache frissites elindult.")
    mysql_conn, sqlite_conn = None, None
    mysql_cursor, sqlite_cursor = None, None
    data = []  

    try:
        mysql_conn = get_mysql_connection()
        mysql_cursor = mysql_conn.cursor()
        mysql_cursor.execute("SELECT PN FROM workorders")
        pn_rows = mysql_cursor.fetchall()
        pn_values = [pn[0] for pn in pn_rows]

        sqlite_conn = get_sqlite_connection()
        sqlite_cursor = sqlite_conn.cursor()
        query = "SELECT `PART.NBR`, PROD FROM t_dump WHERE TRIM(UPPER(`PART.NBR`)) IN ({})".format(
            ",".join(["?"] * len(pn_values))
        )
        sqlite_cursor.execute(query, [pn.upper() for pn in pn_values])
        prod_results = sqlite_cursor.fetchall()

        prod_dict = {row[0].strip().upper(): row[1] for row in prod_results}

        for pn in pn_values:
            prod_value = prod_dict.get(pn.upper(), "N/A")
            data.append({'PN': pn, 'PRODUCTION_TIME': prod_value})

        cache.set('pn_data', data)
        cache.set('total', len(data))
        
        # Print message for cache update
        print("Cache frissitve. PN adatok frissitve a cache-ben.")

    except mysql.connector.Error as mysql_err:
        print(f"MySQL hiba: {mysql_err}")
    except sqlite3.Error as sqlite_err:
        print(f"SQLite hiba: {sqlite_err}")
    except Exception as e:
        print(f"Varatlan hiba: {e}")
    finally:
        if mysql_cursor:
            mysql_cursor.close()
        if mysql_conn:
            mysql_conn.close()
        if sqlite_cursor:
            sqlite_cursor.close()
        if sqlite_conn:
            sqlite_conn.close()

            
def calculate_time_difference(start, stop):
    start_time = datetime.strptime(start, "%Y-%m-%d %H:%M:%S")
    stop_time = datetime.strptime(stop, "%Y-%m-%d %H:%M:%S")
    return (stop_time - start_time).total_seconds()  

def format_time_difference(time_difference):
    if time_difference == 0:
        return "0 hours 0 minutes 0 seconds"
    hours = int(time_difference // 3600)
    minutes = int((time_difference % 3600) // 60)
    seconds = int(time_difference % 60)
    return f"{hours} hours {minutes} minutes {seconds} seconds"
     

# Végpont a cache-ből történő adatlekérdezéshez


# Végpont a cache-ből történő adatlekérdezéshez
@app.route('/get_pn_data', methods=['GET'])
def get_pn_data():
    try:
        page = int(request.args.get('page', 1))
        per_page = int(request.args.get('per_page', 10))
        offset = (page - 1) * per_page

        # Cache lekérdezése
        final_data = cache.get('pn_progress_data')
        
        if final_data is None:
            print("Cache is empty, reloading data...")
            
            final_data = reload_pn_data_cache()
            if not final_data:
                return jsonify({"error": "No data available."}), 500

        # Pagináció
        paginated_data = final_data[offset:offset + per_page]
        response = {
            'data': paginated_data,
            'total': len(final_data),
            'page': page,
            'per_page': per_page,
        }
        return jsonify(response)

    except Exception as e:
        print(f"Error in /get_pn_data endpoint: {e}")
        return jsonify({"error": f"Error occurred: {e}"}), 500


def reload_pn_data_cache():
    
    try:
        mysql_conn = get_mysql_connection()
        mysql_cursor = mysql_conn.cursor(dictionary=True)

        # Egyesített SQL lekérdezés
        query = """
            SELECT 
                wo.WO,
                wo.PN,
                COALESCE(SUM(wwo.QTY), 0) AS total_qty,
                MIN(wwo.start_time) AS first_start_time,
                MAX(wwo.end_time) AS last_end_time,
                GROUP_CONCAT(wwo.start_time ORDER BY wwo.start_time) AS start_times,
                GROUP_CONCAT(wwo.end_time ORDER BY wwo.start_time) AS end_times
            FROM workorders wo
            LEFT JOIN workstationworkorder wwo ON wo.ID = wwo.work_id
            GROUP BY wo.WO, wo.PN
        """
        mysql_cursor.execute(query)
        rows = mysql_cursor.fetchall()

        # SQLite kapcsolat a Production Time lekéréséhez
        sqlite_conn = get_sqlite_connection()
        sqlite_cursor = sqlite_conn.cursor()

        final_data = []
        for row in rows:
            start_times = row['start_times'].split(',') if row['start_times'] else []
            end_times = row['end_times'].split(',') if row['end_times'] else []

            total_effective_time = 0
            total_loss_time = 0
            total_all_time = 0

            # Effective Time számítás
            for start, end in zip(start_times, end_times):
                if start:
                    if not end:
                        end = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    total_effective_time += calculate_time_difference(start, end)

            # Loss/Waited Time számítás
            for i in range(len(end_times) - 1):
                if end_times[i] and start_times[i + 1]:
                    total_loss_time += calculate_time_difference(end_times[i], start_times[i + 1])

            # All Time számítás
            if row['first_start_time']:
                first_start_time = row['first_start_time']
                last_end_time = row['last_end_time'] or datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                total_all_time = calculate_time_difference(first_start_time, last_end_time)

            # Production Time lekérdezése SQLite-ból
                pn_value = row['PN']
                try:
                    # Print debugging info to verify query
                    print(f"Running SQLite query for PN: {pn_value}")

                    query = "SELECT PROD FROM t_dump WHERE TRIM(UPPER(`PART.NBR`)) = ? LIMIT 1"
                    print(f"Executing query: {query} with PN: {pn_value}")

                    sqlite_cursor.execute(query, (pn_value.strip().upper(),))
                    production_time_result = sqlite_cursor.fetchone()

                    # Print the result of the query
                    print(f"PN: {pn_value} | Production Time Query Result: {production_time_result}")

                    production_time = production_time_result[0] if production_time_result else "N/A"

                except Exception as e:
                    # Print detailed error if something goes wrong
                    print(f"Error querying Production Time for PN: {pn_value} | Error: {e}")
                    production_time = "N/A"



            # Csak akkor adjuk hozzá, ha ALL_TIME értéke nem 0
            if total_all_time > 0:
                final_data.append({
                    'WORK_ORDER': row['WO'],
                    'PN': row['PN'],
                    'PRODUCTION_TIME': production_time,
                    'QTY': row['total_qty'],
                    'EFFECTIVE_TIME': f"{total_effective_time / 3600:.2f} hours",
                    'ALL_TIME': f"{total_all_time / 3600:.2f} hours",
                    'LOSS_WAITED_TIME': f"{total_loss_time / 3600:.2f} hours",
                })

        # Cache-be mentés
        cache.set('pn_progress_data', final_data)
        mysql_cursor.close()
        mysql_conn.close()
        sqlite_cursor.close()
        sqlite_conn.close()
        print("Cache updated successfully.")
        return final_data

    except Exception as e:
        print(f"Error reloading cache: {e}")
        return []









@app.route('/api/get_history_data', methods=['GET'])
def get_history_data():
    wo = request.args.get('wo')
    if not wo:
        return jsonify({"error": "WO parameter is missing"}), 400

    try:
        # Connect to the MySQL database
        mysql_conn = get_mysql_connection()
        mysql_cursor = mysql_conn.cursor(dictionary=True)

        # Query to fetch history data with the worker name
        query = """
            SELECT w.name AS worker, ww.start_time, ww.end_time, ww.process_id AS station, ww.next_station_id AS next_station, ww.qty
            FROM workstationworkorder ww
            JOIN workers w ON ww.worker_id = w.ID
            JOIN workorders wo ON ww.work_id = wo.ID
            WHERE wo.WO = %s
            ORDER BY ww.start_time
        """
        mysql_cursor.execute(query, (wo,))
        history_data = mysql_cursor.fetchall()

        mysql_cursor.close()
        mysql_conn.close()

        return jsonify({"data": history_data})
    
    except mysql.connector.Error as e:
        print(f"Database error: {e}")
        return jsonify({"error": "Error retrieving history data"}), 500



































# Route to export data to Excel
@app.route('/api/export_to_excel', methods=['GET'])
def export_to_excel():

    # Fetch real data from the database

    conn = get_db_connection()

    cursor = conn.cursor()

    

    query = """

    SELECT 

        w.ID, 

        w.workstation_id, 

        w.device_id, 

        wo.name AS worker_name, 

        CONCAT('WO: ', wo2.WO, ', PN: ', wo2.PN, '') AS work_order_data, 

        w.start_time,

        w.end_time,

        w.status,

        w.process_id,

        w.next_station_id,
        
        w.qty

    FROM 

        workstationworkorder w

    LEFT JOIN 

        workers wo ON w.worker_id = wo.ID

    LEFT JOIN 

        workorders wo2 ON w.work_id = wo2.id

    """

    

    cursor.execute(query)

    rows = cursor.fetchall()

    cursor.close()

    conn.close()



    # Define column names based on your table structure

    columns = ['ID', 'Workstation ID', 'Device ID', 'Worker Name', 'Work Order Data', 

               'Start Time', 'End Time', 'Status', 'Process ID', 'Next Station ID', 'QTY']

    

    # Create a DataFrame

    df = pd.DataFrame(rows, columns=columns)



    # Create in-memory file

    output = io.BytesIO()

    with pd.ExcelWriter(output, engine='openpyxl') as writer:

        df.to_excel(writer, index=False, sheet_name='UsersData')

        worksheet = writer.sheets['UsersData']

        

        # Enable filtering on all columns

        worksheet.auto_filter.ref = worksheet.dimensions



    output.seek(0)



    # Send file for download

    return send_file(output, as_attachment=True, download_name='Users_Data.xlsx', 

                     mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')



def check_virtualenv_and_packages(ip, username, password):

    username = "user"

    password = "user"

    commands = """

    # Install git if not present

    if ! command -v git &> /dev/null; then

        sudo apt-get update

        sudo apt-get install -y git

    fi



    # Create virtual environment if it doesn't exist

    if [ ! -d "/home/user/myenv" ]; then

        python3 -m venv /home/user/myenv

        source /home/user/myenv/bin/activate

        pip install ttkbootstrap mysql-connector Pillow

        pip install netifaces

    else

        source /home/user/myenv/bin/activate

    fi



    # Clone or update the repository

    cd /home/user

    if [ ! -d "QR-Code-Project" ]; then

        git clone https://github.com/SilcoBat/QR-Code-Project.git || echo "Git clone failed"

    else

        cd QR-Code-Project && git pull || echo "Git pull failed"

    fi



    # Verify the directory and copy files if they exist

    if [ -d "/home/user/QR-Code-Project" ]; then

        cp /home/user/QR-Code-Project/V3.7.py /home/user/Desktop/ || echo "V3.7.py copy failed"

        cp /home/user/QR-Code-Project/logo.png /home/user/ || echo "logo.png copy failed"

        echo "Installed"

    else

        echo "QR-Code-Project directory not found"

    fi

    """

    return execute_command_on_pi(ip, username, password, commands)

#---------------------------------------------------------------------------------------------   TEAM LEADERS   ------------------------------------------------------------------------


from flask import g
from flask_caching import Cache

cache = Cache(config={'CACHE_TYPE': 'SimpleCache', 'CACHE_DEFAULT_TIMEOUT': 30})
cache.init_app(app)

from flask import g
import mysql.connector

def get_db():
    if 'db' not in g or g.db.is_connected() == False:
        g.db = mysql.connector.connect(
            host='10.10.2.15',
            user='root',
            password='admin321',
            database='paperless',
            autocommit=True
        )
    return g.db

@app.teardown_appcontext
def teardown_db(exception):
    db = g.pop('db', None)
    if db is not None:
        db.close()
        
        
from flask import Flask, render_template, request, session, redirect, url_for, make_response
from ldap3 import Server, Connection, ALL, NTLM
import hashlib
import json
app.secret_key = 'supersecretkey'  # Titkos kulcs a session titkosításához

AD_SERVER = 'ldap://10.10.2.12'
BASE_DN = 'DC=INSILCOSK,DC=local'
AD_USERNAME_ATTR = 'sAMAccountName'
AD_NAME_ATTR = 'displayName'
AD_TITLE_ATTR = 'title'

COOKIE_NAME = 'user_auth'  # A cookie neve
def get_user_attributes(conn, username):
    conn.search(
        search_base=BASE_DN,
        search_filter=f'({AD_USERNAME_ATTR}={username})',
        attributes=[AD_NAME_ATTR, AD_TITLE_ATTR]
    )

    if conn.entries:
        user = conn.entries[0]
        return {
            'display_name': user.displayName.value if hasattr(user, 'displayName') else 'N/A',
            'job_title': user.title.value if hasattr(user, 'title') else None,
            'username': username
        }

    return None

def authenticate_user(username, password):
    """Megpróbálja hitelesíteni a felhasználót az Active Directory-ban."""
    user_dn = f'INSILCOSK\\{username}'
    
    try:
        server = Server(AD_SERVER, get_info=ALL)
        conn = Connection(server, user_dn, password, authentication=NTLM, auto_bind=True)

        if conn.bound:
            user_info = get_user_attributes(conn, username)
            
            # 🔍 Logoljuk az AD-ból kapott adatokat
            print(f"[DEBUG] Bejelentkezett felhasználó: {user_info}")

            return user_info  # ✅ Sikeres bejelentkezés

        print("[ERROR] AD hitelesítés sikertelen.")
            
    except Exception as e:
        print(f"[ERROR] Hitelesítési hiba: {e}")
    
    return None  # ❌ Ha nem sikerült a bejelentkezés


@app.route('/api/assembly_data', methods=['GET'])
def api_assembly_data():
    try:
        page = request.args.get('page', 1, type=int)
        per_page = 10
        user_job_title = session.get('user', {}).get('job_title', 'Ismeretlen')

        assembly_data = get_assembly_data(user_job_title, page=page, per_page=per_page)

        return jsonify(assembly_data)

    except mysql.connector.Error as e:
        print(f"MariaDB hiba: {e}")
        return jsonify({"error": str(e)}), 500
    except Exception as e:
        print(f"ltalnos hiba: {e}")
        return jsonify({"error": str(e)}), 500


def get_assembly_data(user_job_title, process_id="ASSEMBLY", page=1, per_page=10):
    """ Lekérdezi az assembly adatokat a kiválasztott process_id alapján """
    try:
        db = get_db()
        cursor = db.cursor(dictionary=True)
        offset = (page - 1) * per_page

        query = """
        SELECT 
            ww.id AS workstation_id,
            ww.worker_id,
            wr.name AS worker_name,
            wo.WO,
            wo.PN,
            ww.start_time,
            ww.end_time,
            ww.process_id,
            ww.next_station_id
        FROM workstationworkorder ww
        LEFT JOIN workers wr ON ww.worker_id = wr.ID
        LEFT JOIN workorders wo ON ww.work_id = wo.ID
        WHERE ww.process_id = %s  -- Itt használjuk az új process_id változót
        ORDER BY ww.ID DESC
        LIMIT %s OFFSET %s
        """
        
        cursor.execute(query, (process_id, per_page, offset))
        results = cursor.fetchall()

        processed_data = []

        for row in results:
            workstation_id = row["workstation_id"]
            worker_name = row["worker_name"] or "Ismeretlen"
            wo_value = row["WO"] or "N/A"
            pn_value = row["PN"] or "N/A"
            start_time = row["start_time"]
            end_time = row["end_time"]

            cursor.execute("SELECT `GROUP` FROM t_dump WHERE `PART.NBR` = %s", (pn_value,))
            t_dump_record = cursor.fetchone()
            group_value = t_dump_record["GROUP"] if t_dump_record else "N/A"

            if row["next_station_id"]:
                status_text = f"Ide lett kuldve: {row['next_station_id']}"
                status_class = "status-current"
                status_icon = "fa-check-circle"
            else:
                status_text = f"Jelenleg itt van: {row['process_id']}"
                status_class = "status-sent"
                status_icon = "fa-arrow-right"

            processed_data.append({
                "id": workstation_id,
                "felhasznalo": worker_name,
                "WO": wo_value,
                "PN": pn_value,
                "GROUP": group_value,
                "start_time": start_time,
                "end_time": end_time,
                "status": status_text,
                "status_class": status_class,
                "status_icon": status_icon
            })
        
        return processed_data

    except mysql.connector.Error as e:
        print(f"MariaDB hiba: {e}")
        return []
    except Exception as e:
        print(f"Általános hiba: {e}")
        return []


@app.route('/api/update_process_and_refresh', methods=['POST'])
def update_process_and_refresh():
    """ Frissíti a táblázatot a kiválasztott process_id alapján (nem módosítja az adatbázist) """
    if 'user' not in session or session['user'].get('job_title', '') != "IT":
        return jsonify({"error": "Unauthorized"}), 403

    data = request.json
    selected_process_id = data.get('new_process_id')  # Az optionbox-ból kapott érték

    if not selected_process_id:
        return jsonify({"error": "Missing parameters"}), 400

    try:
        # Az új process_id alapján lekérjük az adatokat
        refreshed_data = get_assembly_data(user_job_title="IT", process_id=selected_process_id)

        return jsonify({"message": "Data refreshed successfully", "data": refreshed_data}), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500




@app.route('/api/overtime_events', methods=['GET'])
def get_overtime_events():
    try:
        db = get_db()
        cursor = db.cursor(dictionary=True)

        page = request.args.get('page', 1, type=int)
        per_page = 10  # Egy oldalon ennyi elem jelenik meg
        offset = (page - 1) * per_page

        # **Időtúllépett események lekérdezése**
        query = """
        SELECT 
            wr.name AS worker_name,
            COALESCE(wo.WO, 'N/A') AS WO,
            COALESCE(wo.PN, 'N/A') AS PN,
            wo.QTY AS workorder_qty,  -- 🔹 QTY a workorders táblából
            ww.start_time,
            ww.process_id
        FROM workstationworkorder ww
        LEFT JOIN workers wr ON ww.worker_id = wr.ID
        LEFT JOIN workorders wo ON ww.work_id = wo.ID
        WHERE ww.process_id = 'ASSEMBLY'
        AND ww.status = 'Active'
        ORDER BY ww.start_time DESC
        LIMIT %s OFFSET %s
        """

        cursor.execute(query, (per_page, offset))
        results = cursor.fetchall()

        processed_data = []
        now = datetime.now()

        for row in results:
            try:
                start_time = datetime.strptime(row['start_time'], '%Y-%m-%d %H:%M:%S') if row['start_time'] else None
            except (ValueError, TypeError, AttributeError):
                start_time = None

            elapsed_time = (now - start_time).total_seconds() / 3600 if start_time else None  

            # **MariaDB lekérdezés a PROD időhöz**
            try:
                prod_cursor = db.cursor()
                prod_query = "SELECT PROD FROM paperless.t_dump WHERE TRIM(UPPER(`PART.NBR`)) = %s LIMIT 1"
                prod_cursor.execute(prod_query, (row['PN'].strip().upper(),))
                prod_time_result = prod_cursor.fetchone()
                prod_cursor.close()

                prod_time = float(prod_time_result[0]) if prod_time_result else None

            except Exception as e:
                print(f"🔴 Hiba a PROD adat betöltésénél: {e}")
                prod_time = None

            qty = row['workorder_qty'] if row['workorder_qty'] is not None else 'N/A'  # 🔹 QTY érték lekérése a workorders táblából

            if prod_time and elapsed_time and elapsed_time > prod_time:
                processed_data.append({
                    'felhasznalo': row['worker_name'] or 'Ismeretlen',
                    'WO': row['WO'],
                    'PN': row['PN'],
                    'start_time': row['start_time'][:16] if row['start_time'] else '-',
                    'PROD_time': f"{prod_time:.2f} óra",
                    'elapsed_time': f"{elapsed_time:.2f} óra",
                    'QTY': qty  # 🔹 Hozzáadjuk a QTY értéket
                })

        # **Összes találat száma**
        count_query = """
        SELECT COUNT(*) FROM workstationworkorder ww
        LEFT JOIN workorders wo ON ww.work_id = wo.ID
        WHERE ww.process_id = 'ASSEMBLY'
        """
        cursor.execute(count_query)
        total_records = cursor.fetchone()["COUNT(*)"]

        cursor.close()
        db.close()

        return jsonify({
            "data": processed_data,
            "total": total_records,
            "page": page,
            "per_page": per_page
        })

    except mysql.connector.Error as e:
        print(f"🔴 MariaDB hiba: {e}")
        return jsonify({"error": str(e)}), 500
    except Exception as e:
        print(f"🔴 Általános hiba: {e}")
        return jsonify({"error": str(e)}), 500



@app.route('/teamleaders')
@role_required("EMI", "MTE", "MDI", "IT", "SUPERVISOR", "MANAGER")
def teamleaders():
    return render_template('dashboard.html', user=session.get('user'))


@app.route('/teamleaders')
@cache.cached(timeout=10, query_string=True)  
def dashboard():
    if 'user' not in session:
        return redirect(url_for('login'))
    

    page = request.args.get('page', 1, type=int)
    per_page = 10
    
    try:

        db = get_db()
        cursor = db.cursor(dictionary=True)
        cursor.execute("SELECT COUNT(*) AS total FROM workstationworkorder WHERE process_id = 'ASSEMBLY'")
        total_records = cursor.fetchone()['total']
    except Exception as e:
        total_records = 0
    

    assembly_data = get_assembly_data(
        user_job_title=session['user'].get('job_title', 'Ismeretlen'),
        page=page,
        per_page=per_page
    )
    
    total_pages = (total_records + per_page - 1) // per_page
    
    return render_template('dashboard.html',
                         user=session['user'],
                         assembly_data=assembly_data,
                         current_page=page,
                         total_pages=total_pages)

@app.route('/logout')
def logout():
    """Kijelentkezés és cookie törlés."""
    session.pop('user', None)
    response = make_response(redirect(url_for('login')))
    response.set_cookie(COOKIE_NAME, '', expires=0)  # Cookie törlése
    return response

#------------------------------------------------------------------------------- Basic login to AD ----------------------------------------------------

@app.route('/login', methods=['GET', 'POST'])
def login():

    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        user_info = authenticate_user(username, password)

        if user_info:
            session['user'] = user_info  
            job_title = user_info.get('job_title', "").strip().upper()  

            print(f"[DEBUG] Felhasznl: {user_info['display_name']} | Job title: {job_title}")

            if "MANAGER" in job_title:  
                return redirect(url_for('teamleaders'))
            elif "SUPERVISOR" in job_title:
                return redirect(url_for('teamleaders'))
            elif "IT" in job_title:
                return redirect(url_for('index'))
            elif any(keyword in job_title for keyword in ["EMI", "MTE", "MDI"]):
                return redirect(url_for('teamleaders'))
            else:
                flash("Nincs megfelelo jogosultsgod!", "danger")
                return redirect(request.referrer or url_for('index'))  

        flash("Hibs felhasznlnv vagy jelsz!", "danger")

    return render_template('login.html')





        
        
#------------------------------------------------------------------------------------------------------------------------------------------------------        

if __name__ == '__main__':
    # Cache frissítése minden nap hajnal 5-kor
    scheduler = BackgroundScheduler()
    scheduler.add_job(func=load_data_into_cache, trigger="interval", minutes=2)
    cache.delete('pn_progress_data')
    load_data_into_cache()  
    scheduler.start()
    print("Scheduler fut...")
    app.run(debug=True, host='0.0.0.0')

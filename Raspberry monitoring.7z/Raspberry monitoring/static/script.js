document.addEventListener("DOMContentLoaded", function () {
    console.log("[DEBUG] Felhasznloi azonositas folyamatban...");

    fetch("/api/get_user")
        .then(response => response.json())
        .then(data => {
            console.log("[DEBUG] Szerver valasza:", data);

            if (data.username) {
                document.getElementById("username").textContent = "Udv, " + data.username + "!";
            } else {
                document.getElementById("username").textContent = "Nem sikerult azonosutani a felhasznlt.";
            }
        })
        .catch(error => console.error("[ERROR] Hiba tortent a fetch kozben:", error));
});

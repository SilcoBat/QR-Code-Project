import paramiko

# Raspberry Pi IP címek és belépési adatok
devices = [
    {"ip": "10.10.2.77", "username": "user", "password": "user"},
    {"ip": "10.10.2.147", "username": "user", "password": "user"},
    # Add more devices here
]

def execute_command_on_pi(ip, username, password, command):
    try:
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(ip, username=username, password=password)

        stdin, stdout, stderr = client.exec_command(command)
        output = stdout.read().decode().strip()

        client.close()
        return output
    except Exception as e:
        return f"Error connecting to {ip}: {e}"

def monitor_devices():
    for device in devices:
        ip = device["ip"]
        username = device["username"]
        password = device["password"]

        print(f"Monitoring device: {ip}")

        # Uptime
        uptime_command = "uptime -p"
        uptime = execute_command_on_pi(ip, username, password, uptime_command)
        print(f"Uptime: {uptime}")

        # Hőmérséklet
        temp_command = "cat /sys/class/thermal/thermal_zone0/temp"
        temp = execute_command_on_pi(ip, username, password, temp_command)
        if temp.isdigit():
            temp_celsius = int(temp) / 1000
            print(f"Hőmérséklet: {temp_celsius} °C")

        # I/O monitorozás
        io_command = "iostat -d mmcblk0"
        io_stats = execute_command_on_pi(ip, username, password, io_command)
        print(f"I/O statisztikák:\n{io_stats}")

        print("-" * 40)

if __name__ == "__main__":
    monitor_devices()

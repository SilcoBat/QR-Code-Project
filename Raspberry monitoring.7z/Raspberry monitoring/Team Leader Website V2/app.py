from flask import Flask, render_template, jsonify, request, send_file, send_from_directory
from flask_caching import Cache
from apscheduler.schedulers.background import BackgroundScheduler
from tkinter.filedialog import asksaveasfile
import openpyxl
import json
import paramiko
import mysql.connector
import sqlite3
import pandas as pd
from datetime import datetime, timedelta
import io
from ldap3 import Server, Connection, ALL


app = Flask(__name__, static_url_path='/static')

# Cache konfiguráció Redis alapú cache használatával
cache = Cache(app, config={
    'CACHE_TYPE': 'RedisCache',
    'CACHE_REDIS_HOST': 'localhost',
    'CACHE_REDIS_PORT': 6379,
    'CACHE_REDIS_DB': 0,
    'CACHE_DEFAULT_TIMEOUT': 24 * 60 * 60  # 24 órás timeout
})

@app.route('/static/<path:filename>')
def static_files(filename):
    return send_from_directory('static', filename)

# SQLite connection
def get_sqlite_connection():
    return sqlite3.connect(r'/mnt/sqlite_db/test_db.db')

# MySQL connection
def get_mysql_connection():
    return mysql.connector.connect(
        host='10.10.2.15',
        user='root',
        password='admin321',
        database='paperless'
    )

# Adatok olvasÃ¡sa a JSON fÃ¡jlbÃ³l (ahol a Raspberry Pi adatok tÃ¡rolÃ³dnak)

def load_data():

    with open('data/devices.json') as f:

        return json.load(f)



# SSH parancs vÃ©grehajtÃ¡sa a Raspberry Pi-n

def execute_command_on_pi(ip, username, password, command):

    try:

        client = paramiko.SSHClient()

        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

        client.connect(ip, username=username, password=password)

        stdin, stdout, stderr = client.exec_command(command)



        stdout_output = stdout.read().decode().strip()

        stderr_output = stderr.read().decode().strip()



        client.close()



        if stderr_output:

            # If there's any error message, include it in the response

            return f"Error: {stderr_output}"

        return stdout_output

    except Exception as e:

        return f"Error: {e}"



# Function to check virtual environment and packages

def check_virtualenv_and_packages_on_pi(ip, username, password):

    username = "user"

    password = "user"

    command = """

    if [ ! -d "/home/user/myenv" ]; then

        # If the virtual environment does not exist, create and install packages

        python3 -m venv /home/user/myenv

        source /home/user/myenv/bin/activate

        pip install ttkbootstrap mysql-connector Pillow

        pip install netifaces

        echo "Installed"

    else

        # Check if the packages are already installed

        source /home/user/myenv/bin/activate

        if pip show ttkbootstrap && pip show mysql-connector && pip show Pillow; then

            echo "Installed"

        else

            echo "Not Installed"

        fi

    fi

    """

    result = execute_command_on_pi(ip, username, password, command)

    return result



# API vÃ©gpont a fÃ¡jl letÃ¶ltÃ©sÃ©hez Ã©s ellenÅ‘rzÃ©shez

@app.route('/api/download_file', methods=['POST'])

def download_file():

    ip = request.json['ip']

    username = "user"  # Default username

    password = "user"  # Default password

    

    # Check and install necessary virtual environment and packages

    result = check_virtualenv_and_packages_on_pi(ip, username, password)

    

    # Check the result of installation or verification

    if "Installed" in result:

        return jsonify({"result": "Packages installed and verified successfully."})

    elif "Not Installed" in result:

        return jsonify({"result": "Failed to install packages, please check manually."})

    else:

        return jsonify({"result": result})  # Return any other potential output or error





# A fÅ‘oldal megjelenÃ­tÃ©se

@app.route('/')

def index():

    return render_template('index.html')



# Programok Ã¡llapotÃ¡nak ellenÅ‘rzÃ©se oldal

@app.route('/programs')

def programs():

    return render_template('programs.html')



# API vÃ©gpont a Raspberry Pi adatokhoz

@app.route('/api/devices')

def devices_api():

    data = load_data()

    return jsonify(data)



# API vÃ©gpont a program indÃ­tÃ¡sÃ¡hoz

@app.route('/api/start_program', methods=['POST'])

def start_program():

    ip = request.json['ip']

    username = "user"  # Default username

    password = "user"  # Default password

    command = f"/bin/bash -c 'source /home/user/myenv/bin/activate && nohup python /home/user/Desktop/V3.7.py > /home/user/program_output.log 2>&1 &'"

    

    # SSH command to start the program

    result = execute_command_on_pi(ip, username, password, command)

    

    # Check the program log after starting

    check_command = "cat /home/user/program_output.log"

    output = execute_command_on_pi(ip, username, password, check_command)

    return jsonify({"result": f"Program started on {ip}", "log_output": output})





# API vÃ©gpont a program leÃ¡llÃ­tÃ¡sÃ¡hoz

@app.route('/api/stop_program', methods=['POST'])

def stop_program_api():

    ip = request.json['ip']

    username = "user"  # Default username

    password = "user"  # Default password

    

    # SSH command to stop the program

    command = "pkill -f V3.7.py"

    result = execute_command_on_pi(ip, username, password, command)

    return jsonify({"result": f"Program stopped on {ip}", "output": result})





#error html

@app.route('/errors_controller')

def errors_controller():

    return render_template('errors_controller.html')





@app.route('/api/errors_data')

def errors_data():

    conn = get_db_connection()

    cursor = conn.cursor()

    query = "SELECT ID, `Device IP`, `Device Name`, Error, `Error Raised Date`, `Error Solved Date`, `Error Status` FROM errors"

    cursor.execute(query)

    rows = cursor.fetchall()

    cursor.close()

    conn.close()



    # EllenÅ‘rizd, hogy az oszlopnevek helyesek-e

    columns = ['ID', 'Device IP', 'Device Name', 'Error', 'Error Raised Date', 'Error Solved Date', 'Error Status']

    data = [dict(zip(columns, row)) for row in rows]

    return jsonify(data)



# FrissÃ­tÃ©s az 'errors' tÃ¡blÃ¡ban az ID alapjÃ¡n

@app.route('/api/resolve_error', methods=['POST'])

def resolve_error():

    error_id = request.json['id']

    current_date = datetime.now().strftime('%Y-%m-%d %H:%M:%S')



    conn = get_db_connection()

    cursor = conn.cursor()



    query = """

        UPDATE errors 

        SET `Error Solved Date` = %s, `Error Status` = 'Completed' 

        WHERE ID = %s

    """

    cursor.execute(query, (current_date, error_id))

    conn.commit()

    cursor.close()

    conn.close()



    return jsonify({"result": "Error resolved successfully."})



# Rekord tÃ¶rlÃ©se az 'errors' tÃ¡blÃ¡bÃ³l az ID alapjÃ¡n

@app.route('/api/delete_error', methods=['POST'])

def delete_error():

    error_id = request.json['id']



    conn = get_db_connection()

    cursor = conn.cursor()



    query = "DELETE FROM errors WHERE ID = %s"

    cursor.execute(query, (error_id,))

    conn.commit()

    cursor.close()

    conn.close()



    return jsonify({"result": "Error deleted successfully."})



# API vÃ©gpont a parancsok futtatÃ¡sÃ¡hoz

@app.route('/api/run_command', methods=['POST'])

def run_command():

    ip = request.json['ip']

    command_type = request.json['command']  # 'Restart' or 'Update'

    username = "user"  # Default username

    password = "user"  # Default password



    if command_type == "Restart":

        # 1. Stop the program

        stop_command = "pkill -f V3.7.py"

        stop_result = execute_command_on_pi(ip, username, password, stop_command)



        # 2. Restart the program

        start_command = f"/bin/bash -c 'source /home/user/myenv/bin/activate && nohup python /home/user/Desktop/V3.7.py > /home/user/program_output.log 2>&1 &'"

        start_result = execute_command_on_pi(ip, username, password, start_command)

        

        return jsonify({"result": f"Program restarted on {ip}", "stop_output": stop_result, "start_output": start_result})



    elif command_type == "Update":

        # 1. Stop the program

        stop_command = "pkill -f V3.7.py"

        stop_result = execute_command_on_pi(ip, username, password, stop_command)



        # 2. Delete the virtual environment and the program

        delete_command = "rm -rf /home/user/myenv /home/user/Desktop/V3.7.py"

        delete_result = execute_command_on_pi(ip, username, password, delete_command)



        # 3. Reinstall the virtual environment and the program

        update_result = check_virtualenv_and_packages(ip, username, password)



        # 4. Restart the program

        start_command = f"/bin/bash -c 'source /home/user/myenv/bin/activate && nohup python /home/user/Desktop/V3.7.py > /home/user/program_output.log 2>&1 &'"

        start_result = execute_command_on_pi(ip, username, password, start_command)

        

        return jsonify({

            "result": f"Program updated and restarted on {ip}", 

            "stop_output": stop_result, 

            "delete_output": delete_result, 

            "update_output": update_result, 

            "start_output": start_result

        })







# API endpoint to update a user's record

@app.route('/api/update_user/<int:id>', methods=['POST'])

def update_user(id):

    data = request.json

    conn = get_db_connection()

    cursor = conn.cursor()

    query = """

    UPDATE workstationworkorder

    SET start_time = %s, end_time = %s, status = %s, process_id = %s, next_station_id = %s

    WHERE ID = %s

    """

    cursor.execute(query, (data['Start Time'], data['End Time'], data['Status'], data['Process ID'], data['Next Station ID'], id))

    conn.commit()

    cursor.close()

    conn.close()

    return jsonify({"message": "Record updated successfully"})



# API endpoint to delete a user's record

@app.route('/api/delete_user/<int:id>', methods=['DELETE'])

def delete_user(id):

    conn = get_db_connection()

    cursor = conn.cursor()

    query = "DELETE FROM workstationworkorder WHERE ID = %s"

    cursor.execute(query, (id,))

    conn.commit()

    cursor.close()

    conn.close()

    return jsonify({"message": "Record deleted successfully"})



# API endpoint to delete selected users

@app.route('/api/delete_selected', methods=['POST'])

def delete_selected_users():

    data = request.json

    ids = data['ids']  # Get the list of IDs to delete

    if not ids:

        return jsonify({"message": "No IDs provided"}), 400



    conn = get_db_connection()

    cursor = conn.cursor()

    query = "DELETE FROM workstationworkorder WHERE ID IN (%s)" % ','.join(['%s'] * len(ids))

    cursor.execute(query, ids)

    conn.commit()

    cursor.close()

    conn.close()



    return jsonify({"message": "Selected records deleted successfully"})



@app.route('/api/update_program', methods=['POST'])

def update_program():

    ip = request.json['ip']

    

    # Default credentials for Raspberry Pi devices

    username = "user"

    password = "user"

    

    # Stop the running program first

    stop_command = "pkill -f V3.7.py"

    stop_result = execute_command_on_pi(ip, username, password, stop_command)



    # Remove the existing environment and program files

    remove_command = "rm -rf /home/user/myenv /home/user/Desktop/V3.7.py"

    remove_result = execute_command_on_pi(ip, username, password, remove_command)



    # Reinstall the virtual environment and program

    reinstall_result = check_virtualenv_and_packages(ip, username, password)

    

    # Start the program after reinstalling

    start_command = "/bin/bash -c 'source /home/user/myenv/bin/activate && nohup python /home/user/Desktop/V3.7.py > /home/user/program_output.log 2>&1 &'"

    start_result = execute_command_on_pi(ip, username, password, start_command)



    return jsonify({"result": f"Program updated and restarted on {ip}", "stop_output": stop_result, "reinstall_output": reinstall_result, "start_output": start_result})





# MariaDB kapcsolat beÃ¡llÃ­tÃ¡sa

def get_db_connection():

    return mysql.connector.connect(

        host='10.10.2.15',

        database='paperless',

        user='root',

        password='admin321'

    )



# Adatok lekÃ©rdezÃ©se a tÃ¡blÃ¡bÃ³l

def fetch_data():
    conn = get_db_connection()
    cursor = conn.cursor()
    query = """
    SELECT 
        w.ID, 
        w.workstation_id, 
        w.device_id, 
        wo.name AS worker_name, 
        CONCAT('WO: ', wo2.WO, ', PN: ', wo2.PN, '') AS work_order_data, 
        w.start_time,
        w.end_time,
        w.status,
        w.process_id,
        w.next_station_id,
        w.qty  -- Ensure QTY is included here
    FROM 
        workstationworkorder w
    LEFT JOIN 
        workers wo ON w.worker_id = wo.ID
    LEFT JOIN 
        workorders wo2 ON w.work_id = wo2.id
    """
    cursor.execute(query)
    rows = cursor.fetchall()
    cursor.close()
    conn.close()
    
    return rows[::-1]






@app.route('/users_controller')

def users_controller():

    columns = ['ID', 'Workstation ID', 'Device ID', 'Worker Name', 'Work Order Data', 'Start Time', 'End Time', 'Status', 'Process ID', 'Next Station ID', 'QTY']

    rows = fetch_data()

    return render_template('users_controller.html', columns=columns, rows=rows)



@app.route('/api/users_data')

def users_data():

    rows = fetch_data()

    columns = ['ID', 'Workstation ID', 'Device ID', 'Worker Name', 'Work Order Data', 'Start Time', 'End Time', 'Status', 'Process ID', 'Next Station ID', 'QTY']

    

    data = [dict(zip(columns, row)) for row in rows]

    return jsonify(data)













@app.route('/users_controller_formanagers')
def users_controller_formanagers():
    return render_template('user_controller_formanagers.html')

@app.route('/pn_progress')
def pn_progress():
    return render_template('pn_progress.html')
    
@app.route('/users_progress')
def users_progress():
    return render_template('users_progress.html')
    


@app.route('/api/users_progress', methods=['GET'])
def users_progress_data():
    conn = get_mysql_connection()
    cursor = conn.cursor(dictionary=True)

    selected_date = request.args.get('date')
    if not selected_date:
        return jsonify({"error": "No date provided. Please select a date."}), 400

    print(f"[DEBUG] Selected date: {selected_date}")

    try:
        # All time query
        all_time_query = """
            SELECT w.name AS user,
                   TIMESTAMPDIFF(
                       SECOND,
                       MIN(ws.login_date),
                       MAX(CASE
                           WHEN DATE(ws.logout_date) = %s THEN ws.logout_date
                           ELSE NULL
                       END)
                   ) AS duration
            FROM workers w
            LEFT JOIN workerworkstation ws ON w.ID = ws.worker_id
            WHERE DATE(ws.login_date) = %s
            GROUP BY w.name
        """
        cursor.execute(all_time_query, (selected_date, selected_date))
        all_time_results = cursor.fetchall()
        all_time_dict = {row['user']: row['duration'] or 0 for row in all_time_results}
        print(f"[DEBUG] All Time Dict: {all_time_dict}")

        # Effective time query
        effective_time_query = """
            SELECT
                w.name AS user,
                SUM(
                    CASE
                        WHEN DATE(ww.start_time) = %s AND DATE(ww.end_time) = %s THEN
                            TIMESTAMPDIFF(SECOND,
                                GREATEST(ww.start_time, CONCAT(%s, ' 00:00:00')),
                                LEAST(ww.end_time, CONCAT(%s, ' 23:59:59'))
                            )
                        ELSE 0
                    END
                ) AS effective_time,
                COUNT(DISTINCT ww.id) AS total_wo
            FROM workers w
            LEFT JOIN workstationworkorder ww ON w.ID = ww.worker_id
            WHERE ww.status = 'Completed'
            AND DATE(ww.start_time) = %s
            GROUP BY w.name
        """

        cursor.execute(effective_time_query, (selected_date, selected_date, selected_date, selected_date, selected_date))
        effective_time_results = cursor.fetchall()




        for row in effective_time_results:
            print(f"[DEBUG] User: {row['user']}")

        # Combine results
        results = []
        for row in effective_time_results:
            user = row['user']
            effective_time = row.get('effective_time', 0)
            total_wo = row.get('total_wo', 0)
            all_time = all_time_dict.get(user, 0)

            # Ensure Effective Time does not exceed All Time
            if effective_time > all_time:
                effective_time = all_time

            # Calculate Loss/Waited Time
            loss_waited = max(all_time - effective_time, 0)

            results.append({
                'user': user,
                'effective_time': format_time_difference(effective_time),
                'all_time': format_time_difference(all_time),
                'loss_waited': format_time_difference(loss_waited),
                'total_wo': total_wo
            })


        print(f"[DEBUG] Final Combined Results: {results}")
        return jsonify(results)

    except Exception as e:
        print(f"[ERROR] Error processing users_progress_data: {e}")
        return jsonify({"error": str(e)}), 500

    finally:
        cursor.close()
        conn.close()


from io import BytesIO
from flask import send_file

def seconds_to_hms(seconds):
    """Convert seconds to a string in hh:mm:ss format."""
    if not seconds or seconds == 0:
        return "0 hours 0 minutes 0 seconds"
    hours = seconds // 3600
    minutes = (seconds % 3600) // 60
    secs = seconds % 60
    return f"{hours} hours {minutes} minutes {secs} seconds"

def adjust_column_width(ws):
    """Adjust the width of Excel columns based on the longest text in each column."""
    for col in ws.columns:
        max_length = 0
        col_letter = col[0].column_letter  # Get the column letter (A, B, etc.)
        for cell in col:
            try:  # Ignore any empty cells
                if cell.value:
                    max_length = max(max_length, len(str(cell.value)))
            except Exception as e:
                print(f"[DEBUG] Error calculating column width: {e}")
        adjusted_width = max_length + 2  # Add padding for readability
        ws.column_dimensions[col_letter].width = adjusted_width


@app.route('/api/users_progress_month', methods=['GET'])
def users_progress_month():
    conn = get_mysql_connection()
    cursor = conn.cursor(dictionary=True)

    year = request.args.get('year')
    month = request.args.get('month')
    if not year or not month:
        return jsonify({"error": "Year and month must be provided."}), 400

    try:
        # Calculate the start and end dates for the given month
        month_start = datetime(int(year), int(month), 1)
        next_month = (month_start.replace(day=28) + timedelta(days=4)).replace(day=1)
        month_end = next_month - timedelta(days=1)

        print(f"[DEBUG] Month Start: {month_start}, Month End: {month_end}")

        # All time query for the entire month
        all_time_query = """
            SELECT w.name AS user,
                   TIMESTAMPDIFF(
                       SECOND,
                       MIN(ws.login_date),
                       MAX(ws.logout_date)
                   ) AS duration
            FROM workers w
            LEFT JOIN workerworkstation ws ON w.ID = ws.worker_id
            WHERE ws.login_date BETWEEN %s AND %s
            GROUP BY w.name
        """
        cursor.execute(all_time_query, (month_start, month_end))
        all_time_results = cursor.fetchall()
        all_time_dict = {row['user']: row['duration'] or 0 for row in all_time_results}

        # Effective time query for the entire month
        effective_time_query = """
            SELECT
                w.name AS user,
                SUM(
                    CASE
                        WHEN ww.start_time BETWEEN %s AND %s THEN
                            TIMESTAMPDIFF(SECOND,
                                GREATEST(ww.start_time, %s),
                                LEAST(ww.end_time, %s)
                            )
                        ELSE 0
                    END
                ) AS effective_time,
                COUNT(DISTINCT ww.id) AS total_wo
            FROM workers w
            LEFT JOIN workstationworkorder ww ON w.ID = ww.worker_id
            WHERE ww.status = 'Completed' AND ww.start_time BETWEEN %s AND %s
            GROUP BY w.name
        """
        cursor.execute(effective_time_query, (month_start, month_end, month_start, month_end, month_start, month_end))
        effective_time_results = cursor.fetchall()

        # Combine results
        results = []
        for row in effective_time_results:
            user = row['user']
            effective_time = row.get('effective_time', 0)
            total_wo = row.get('total_wo', 0)
            all_time = all_time_dict.get(user, 0)

            if effective_time > all_time:
                effective_time = all_time

            loss_waited = max(all_time - effective_time, 0)

            results.append({
                'user': user,
                'effective_time': seconds_to_hms(effective_time),
                'all_time': seconds_to_hms(all_time),
                'loss_waited': seconds_to_hms(loss_waited),
                'total_wo': total_wo
            })

        # Generate Excel file in memory
        output = BytesIO()
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Users Progress Month"

        # Add headers
        headers = ["User", "Effective Time", "All Time", "Loss/Waited", "Total Work Orders"]
        ws.append(headers)

        # Add rows with formatted time
        for result in results:
            ws.append([
                result['user'],
                result['effective_time'],
                result['all_time'],
                result['loss_waited'],
                result['total_wo']
            ])

        # Adjust column widths
        adjust_column_width(ws)

        # Save the workbook to the in-memory file
        wb.save(output)
        output.seek(0)

        # Return the file as a downloadable response
        filename = f"Users_Progress_Month_{year}_{month}.xlsx"
        return send_file(output, as_attachment=True, download_name=filename, mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')

    except Exception as e:
        print(f"[ERROR] Error processing users_progress_month: {e}")
        return jsonify({"error": str(e)}), 500

    finally:
        cursor.close()
        conn.close()












def format_time(seconds):
    if not seconds or seconds == 0:
        return "0 hours 0 minutes 0 seconds"
    hours = seconds // 3600
    minutes = (seconds % 3600) // 60
    secs = seconds % 60
    return f"{hours} hours {minutes} minutes {secs} seconds"

def format_time_difference(seconds):
    """Format time difference into hours, minutes, and seconds."""
    if seconds is None or seconds <= 0:
        return "0 hours 0 minutes 0 seconds"
    hours = int(seconds // 3600)
    minutes = int((seconds % 3600) // 60)
    seconds = int(seconds % 60)
    return f"{hours} hours {minutes} minutes {seconds} seconds"

















# Adatok cache-be töltése
def load_data_into_cache():
    print("Cache frissites elindult.")
    mysql_conn, sqlite_conn = None, None
    mysql_cursor, sqlite_cursor = None, None
    data = []  

    try:
        mysql_conn = get_mysql_connection()
        mysql_cursor = mysql_conn.cursor()
        mysql_cursor.execute("SELECT PN FROM workorders")
        pn_rows = mysql_cursor.fetchall()
        pn_values = [pn[0] for pn in pn_rows]

        sqlite_conn = get_sqlite_connection()
        sqlite_cursor = sqlite_conn.cursor()
        query = "SELECT `PART.NBR`, PROD FROM t_dump WHERE TRIM(UPPER(`PART.NBR`)) IN ({})".format(
            ",".join(["?"] * len(pn_values))
        )
        sqlite_cursor.execute(query, [pn.upper() for pn in pn_values])
        prod_results = sqlite_cursor.fetchall()

        prod_dict = {row[0].strip().upper(): row[1] for row in prod_results}

        for pn in pn_values:
            prod_value = prod_dict.get(pn.upper(), "N/A")
            data.append({'PN': pn, 'PRODUCTION_TIME': prod_value})

        cache.set('pn_data', data)
        cache.set('total', len(data))
        
        # Print message for cache update
        print("Cache frissitve. PN adatok frissitve a cache-ben.")

    except mysql.connector.Error as mysql_err:
        print(f"MySQL hiba: {mysql_err}")
    except sqlite3.Error as sqlite_err:
        print(f"SQLite hiba: {sqlite_err}")
    except Exception as e:
        print(f"Varatlan hiba: {e}")
    finally:
        if mysql_cursor:
            mysql_cursor.close()
        if mysql_conn:
            mysql_conn.close()
        if sqlite_cursor:
            sqlite_cursor.close()
        if sqlite_conn:
            sqlite_conn.close()

            
def calculate_time_difference(start, stop):
    start_time = datetime.strptime(start, "%Y-%m-%d %H:%M:%S")
    stop_time = datetime.strptime(stop, "%Y-%m-%d %H:%M:%S")
    return (stop_time - start_time).total_seconds()  

def format_time_difference(time_difference):
    if time_difference == 0:
        return "0 hours 0 minutes 0 seconds"
    hours = int(time_difference // 3600)
    minutes = int((time_difference % 3600) // 60)
    seconds = int(time_difference % 60)
    return f"{hours} hours {minutes} minutes {seconds} seconds"
     

# Végpont a cache-ből történő adatlekérdezéshez


# Végpont a cache-ből történő adatlekérdezéshez
@app.route('/get_pn_data', methods=['GET'])
def get_pn_data():
    try:
        page = int(request.args.get('page', 1))
        per_page = int(request.args.get('per_page', 10))
        offset = (page - 1) * per_page

        # Cache lekérdezése
        final_data = cache.get('pn_progress_data')
        
        if final_data is None:
            print("Cache is empty, reloading data...")
            
            final_data = reload_pn_data_cache()
            if not final_data:
                return jsonify({"error": "No data available."}), 500

        # Pagináció
        paginated_data = final_data[offset:offset + per_page]
        response = {
            'data': paginated_data,
            'total': len(final_data),
            'page': page,
            'per_page': per_page,
        }
        return jsonify(response)

    except Exception as e:
        print(f"Error in /get_pn_data endpoint: {e}")
        return jsonify({"error": f"Error occurred: {e}"}), 500


def reload_pn_data_cache():
    
    try:
        mysql_conn = get_mysql_connection()
        mysql_cursor = mysql_conn.cursor(dictionary=True)

        # Egyesített SQL lekérdezés
        query = """
            SELECT 
                wo.WO,
                wo.PN,
                COALESCE(SUM(wwo.QTY), 0) AS total_qty,
                MIN(wwo.start_time) AS first_start_time,
                MAX(wwo.end_time) AS last_end_time,
                GROUP_CONCAT(wwo.start_time ORDER BY wwo.start_time) AS start_times,
                GROUP_CONCAT(wwo.end_time ORDER BY wwo.start_time) AS end_times
            FROM workorders wo
            LEFT JOIN workstationworkorder wwo ON wo.ID = wwo.work_id
            GROUP BY wo.WO, wo.PN
        """
        mysql_cursor.execute(query)
        rows = mysql_cursor.fetchall()

        # SQLite kapcsolat a Production Time lekéréséhez
        sqlite_conn = get_sqlite_connection()
        sqlite_cursor = sqlite_conn.cursor()

        final_data = []
        for row in rows:
            start_times = row['start_times'].split(',') if row['start_times'] else []
            end_times = row['end_times'].split(',') if row['end_times'] else []

            total_effective_time = 0
            total_loss_time = 0
            total_all_time = 0

            # Effective Time számítás
            for start, end in zip(start_times, end_times):
                if start:
                    if not end:
                        end = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    total_effective_time += calculate_time_difference(start, end)

            # Loss/Waited Time számítás
            for i in range(len(end_times) - 1):
                if end_times[i] and start_times[i + 1]:
                    total_loss_time += calculate_time_difference(end_times[i], start_times[i + 1])

            # All Time számítás
            if row['first_start_time']:
                first_start_time = row['first_start_time']
                last_end_time = row['last_end_time'] or datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                total_all_time = calculate_time_difference(first_start_time, last_end_time)

            # Production Time lekérdezése SQLite-ból
                pn_value = row['PN']
                try:
                    # Print debugging info to verify query
                    print(f"Running SQLite query for PN: {pn_value}")

                    query = "SELECT PROD FROM t_dump WHERE TRIM(UPPER(`PART.NBR`)) = ? LIMIT 1"
                    print(f"Executing query: {query} with PN: {pn_value}")

                    sqlite_cursor.execute(query, (pn_value.strip().upper(),))
                    production_time_result = sqlite_cursor.fetchone()

                    # Print the result of the query
                    print(f"PN: {pn_value} | Production Time Query Result: {production_time_result}")

                    production_time = production_time_result[0] if production_time_result else "N/A"

                except Exception as e:
                    # Print detailed error if something goes wrong
                    print(f"Error querying Production Time for PN: {pn_value} | Error: {e}")
                    production_time = "N/A"



            # Csak akkor adjuk hozzá, ha ALL_TIME értéke nem 0
            if total_all_time > 0:
                final_data.append({
                    'WORK_ORDER': row['WO'],
                    'PN': row['PN'],
                    'PRODUCTION_TIME': production_time,
                    'QTY': row['total_qty'],
                    'EFFECTIVE_TIME': f"{total_effective_time / 3600:.2f} hours",
                    'ALL_TIME': f"{total_all_time / 3600:.2f} hours",
                    'LOSS_WAITED_TIME': f"{total_loss_time / 3600:.2f} hours",
                })

        # Cache-be mentés
        cache.set('pn_progress_data', final_data)
        mysql_cursor.close()
        mysql_conn.close()
        sqlite_cursor.close()
        sqlite_conn.close()
        print("Cache updated successfully.")
        return final_data

    except Exception as e:
        print(f"Error reloading cache: {e}")
        return []









@app.route('/api/get_history_data', methods=['GET'])
def get_history_data():
    wo = request.args.get('wo')
    if not wo:
        return jsonify({"error": "WO parameter is missing"}), 400

    try:
        # Connect to the MySQL database
        mysql_conn = get_mysql_connection()
        mysql_cursor = mysql_conn.cursor(dictionary=True)

        # Query to fetch history data with the worker name
        query = """
            SELECT w.name AS worker, ww.start_time, ww.end_time, ww.process_id AS station, ww.next_station_id AS next_station, ww.qty
            FROM workstationworkorder ww
            JOIN workers w ON ww.worker_id = w.ID
            JOIN workorders wo ON ww.work_id = wo.ID
            WHERE wo.WO = %s
            ORDER BY ww.start_time
        """
        mysql_cursor.execute(query, (wo,))
        history_data = mysql_cursor.fetchall()

        mysql_cursor.close()
        mysql_conn.close()

        return jsonify({"data": history_data})
    
    except mysql.connector.Error as e:
        print(f"Database error: {e}")
        return jsonify({"error": "Error retrieving history data"}), 500



































# Route to export data to Excel
@app.route('/api/export_to_excel', methods=['GET'])
def export_to_excel():

    # Fetch real data from the database

    conn = get_db_connection()

    cursor = conn.cursor()

    

    query = """

    SELECT 

        w.ID, 

        w.workstation_id, 

        w.device_id, 

        wo.name AS worker_name, 

        CONCAT('WO: ', wo2.WO, ', PN: ', wo2.PN, '') AS work_order_data, 

        w.start_time,

        w.end_time,

        w.status,

        w.process_id,

        w.next_station_id,
        
        w.qty

    FROM 

        workstationworkorder w

    LEFT JOIN 

        workers wo ON w.worker_id = wo.ID

    LEFT JOIN 

        workorders wo2 ON w.work_id = wo2.id

    """

    

    cursor.execute(query)

    rows = cursor.fetchall()

    cursor.close()

    conn.close()



    # Define column names based on your table structure

    columns = ['ID', 'Workstation ID', 'Device ID', 'Worker Name', 'Work Order Data', 

               'Start Time', 'End Time', 'Status', 'Process ID', 'Next Station ID', 'QTY']

    

    # Create a DataFrame

    df = pd.DataFrame(rows, columns=columns)



    # Create in-memory file

    output = io.BytesIO()

    with pd.ExcelWriter(output, engine='openpyxl') as writer:

        df.to_excel(writer, index=False, sheet_name='UsersData')

        worksheet = writer.sheets['UsersData']

        

        # Enable filtering on all columns

        worksheet.auto_filter.ref = worksheet.dimensions



    output.seek(0)



    # Send file for download

    return send_file(output, as_attachment=True, download_name='Users_Data.xlsx', 

                     mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')



def check_virtualenv_and_packages(ip, username, password):

    username = "user"

    password = "user"

    commands = """

    # Install git if not present

    if ! command -v git &> /dev/null; then

        sudo apt-get update

        sudo apt-get install -y git

    fi



    # Create virtual environment if it doesn't exist

    if [ ! -d "/home/user/myenv" ]; then

        python3 -m venv /home/user/myenv

        source /home/user/myenv/bin/activate

        pip install ttkbootstrap mysql-connector Pillow

        pip install netifaces

    else

        source /home/user/myenv/bin/activate

    fi



    # Clone or update the repository

    cd /home/user

    if [ ! -d "QR-Code-Project" ]; then

        git clone https://github.com/SilcoBat/QR-Code-Project.git || echo "Git clone failed"

    else

        cd QR-Code-Project && git pull || echo "Git pull failed"

    fi



    # Verify the directory and copy files if they exist

    if [ -d "/home/user/QR-Code-Project" ]; then

        cp /home/user/QR-Code-Project/V3.7.py /home/user/Desktop/ || echo "V3.7.py copy failed"

        cp /home/user/QR-Code-Project/logo.png /home/user/ || echo "logo.png copy failed"

        echo "Installed"

    else

        echo "QR-Code-Project directory not found"

    fi

    """

    return execute_command_on_pi(ip, username, password, commands)

#---------------------------------------------------------------------------------------------   TEAM LEADERS   ------------------------------------------------------------------------


from flask import g
from flask_caching import Cache

cache = Cache(config={'CACHE_TYPE': 'SimpleCache', 'CACHE_DEFAULT_TIMEOUT': 30})
cache.init_app(app)

def get_db():
    if 'db' not in g:
        g.db = mysql.connector.connect(
        host='10.10.2.15',
        user='root',
        password='admin321',
        database='paperless'
        )
    return g.db

@app.teardown_appcontext
def teardown_db(exception):
    db = g.pop('db', None)
    if db is not None:
        db.close()
        
        
from flask import Flask, render_template, request, session, redirect, url_for, make_response
from ldap3 import Server, Connection, ALL, NTLM
import hashlib
import json
app.secret_key = 'supersecretkey'  # Titkos kulcs a session titkosításához

AD_SERVER = 'ldap://10.10.2.12'
BASE_DN = 'DC=INSILCOSK,DC=local'
AD_USERNAME_ATTR = 'sAMAccountName'
AD_NAME_ATTR = 'displayName'
AD_TITLE_ATTR = 'title'

COOKIE_NAME = 'user_auth'  # A cookie neve

def authenticate_user(username, password):
    """Megpróbál hitelesíteni egy felhasználót az AD-ban."""
    user_dn = f'INSILCOSK\\{username}'
    try:
        server = Server(AD_SERVER, get_info=ALL)
        conn = Connection(server, user_dn, password, authentication=NTLM, auto_bind=True)

        if conn.bound:
            return get_user_attributes(conn, username)
    except Exception as e:
        print(f"[ERROR] Hitelesítési hiba: {e}")
    return None

def get_user_attributes(conn, username):
    """Lekéri a felhasználó adatait az Active Directoryból."""
    conn.search(
        search_base=BASE_DN,
        search_filter=f'({AD_USERNAME_ATTR}={username})',
        attributes=[AD_NAME_ATTR, AD_TITLE_ATTR]
    )
    if conn.entries:
        user = conn.entries[0]
        return {
            'display_name': user.displayName.value if hasattr(user, 'displayName') else 'N/A',
            'job_title': user.title.value if hasattr(user, 'title') else 'N/A',
            'username': username  # A cookie-ban tároljuk
        }
    return None
    


@app.route('/api/assembly_data', methods=['GET'])
def api_assembly_data():
    page = request.args.get('page', 1, type=int)
    per_page = 10
    assembly_data = get_assembly_data(
        user_job_title=session.get('user', {}).get('job_title', 'Ismeretlen'),
        page=page,
        per_page=per_page
    )
    return jsonify(assembly_data)

def get_assembly_data(user_job_title, page=1, per_page=10):
    try:
        db = get_db()
        cursor = db.cursor(dictionary=True)

        offset = (page - 1) * per_page

        query = """
        SELECT 
            ww.worker_id,
            wr.name AS worker_name,
            COALESCE(wo.WO, 'N/A') AS WO,
            COALESCE(wo.PN, 'N/A') AS PN,
            ww.start_time,
            ww.end_time,
            ww.process_id,
            ww.next_station_id
        FROM workstationworkorder ww
        LEFT JOIN workers wr ON ww.worker_id = wr.ID
        LEFT JOIN workorders wo ON ww.work_id = wo.ID
        WHERE ww.process_id = 'ASSEMBLY'
        ORDER BY ww.start_time DESC
        LIMIT %s OFFSET %s
        """

        cursor.execute(query, (per_page, offset))
        results = cursor.fetchall()

        processed_data = []
        for row in results:
            try:
                start_time = datetime.strptime(row['start_time'], '%Y-%m-%d %H:%M:%S').strftime('%Y.%m.%d %H:%M') if row['start_time'] else '-'
                end_time = datetime.strptime(row['end_time'], '%Y-%m-%d %H:%M:%S').strftime('%Y.%m.%d %H:%M') if row['end_time'] else '-'
            except (ValueError, TypeError, AttributeError):
                start_time = row['start_time'][:16] if row['start_time'] else '-'
                end_time = row['end_time'][:16] if row['end_time'] else '-'

            processed_data.append({
                'felhasznalo': row['worker_name'] or 'Ismeretlen',
                'WO': row['WO'],
                'PN': row['PN'],
                'start_time': start_time,
                'end_time': end_time,
                'status': "Jelenleg itt van: ASSEMBLY" if not row['next_station_id'] else f"Ide lett kuldve: {row['next_station_id']}",
                'status_class': "status-current" if not row['next_station_id'] else "status-sent",
                'status_icon': "fa-check-circle" if not row['next_station_id'] else "fa-arrow-right"
            })

        return processed_data
    except mysql.connector.Error as e:
        print(f"MariaDB hiba: {e}")
        return []
    except Exception as e:
        print(f"altalanos hiba: {e}")
        return []

@app.route('/teamleaders', methods=['GET', 'POST'])
def login():
    """Bejelentkezés kezelése."""
    # Ellenőrizzük, van-e érvényes cookie
    if request.cookies.get(COOKIE_NAME):
        try:
            user_data = json.loads(request.cookies.get(COOKIE_NAME))
            session['user'] = user_data
            return redirect(url_for('dashboard'))
        except Exception as e:
            print(f"[ERROR] Cookie beolvasási hiba: {e}")

    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        user_info = authenticate_user(username, password)
        if user_info:
            session['user'] = user_info

            # Cookie beállítása (soha ne járjon le)
            response = make_response(redirect(url_for('dashboard')))
            response.set_cookie(COOKIE_NAME, json.dumps(user_info), httponly=True)  # **Nincs max_age!**
            return response
        else:
            return render_template('login.html', error="Hibás felhasználónév vagy jelszó.")

    return render_template('login.html')


@app.route('/dashboard')
@cache.cached(timeout=10, query_string=True)  
def dashboard():
    if 'user' not in session:
        return redirect(url_for('login'))
    

    page = request.args.get('page', 1, type=int)
    per_page = 10
    
    try:

        db = get_db()
        cursor = db.cursor(dictionary=True)
        cursor.execute("SELECT COUNT(*) AS total FROM workstationworkorder WHERE process_id = 'ASSEMBLY'")
        total_records = cursor.fetchone()['total']
    except Exception as e:
        total_records = 0
    

    assembly_data = get_assembly_data(
        user_job_title=session['user'].get('job_title', 'Ismeretlen'),
        page=page,
        per_page=per_page
    )
    
    total_pages = (total_records + per_page - 1) // per_page
    
    return render_template('dashboard.html',
                         user=session['user'],
                         assembly_data=assembly_data,
                         current_page=page,
                         total_pages=total_pages)

@app.route('/logout')
def logout():
    """Kijelentkezés és cookie törlés."""
    session.pop('user', None)
    response = make_response(redirect(url_for('login')))
    response.set_cookie(COOKIE_NAME, '', expires=0)  # Cookie törlése
    return response



if __name__ == '__main__':
    # Cache frissítése minden nap hajnal 5-kor
    scheduler = BackgroundScheduler()
    scheduler.add_job(func=load_data_into_cache, trigger="interval", minutes=2)
    cache.delete('pn_progress_data')
    load_data_into_cache()  
    scheduler.start()
    print("Scheduler fut...")
    app.run(debug=True, host='0.0.0.0')

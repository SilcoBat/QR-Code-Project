import paramiko
import time
from datetime import datetime
import mysql.connector
from mysql.connector import Error
import threading
import pandas as pd
import csv
import pandas as pd
import json
from pathlib import Path
import requests
import openpyxl
from openpyxl.chart import BarChart, Reference
from openpyxl.utils import get_column_letter

class RaspberryScheduler:
    def __init__(self, db_config, virtual_env_path, script_path, excel_file_path, report_path):
        self.db_config = db_config
        self.virtual_env_path = virtual_env_path
        self.script_path = script_path
        self.excel_file_path = excel_file_path
        self.last_stop_time = None
        self.last_start_time = None
        self.last_import_time = None
        self.last_report_time = None
        self.report_path = report_path  
        self.ssh_username = "user"
        self.ssh_password = "user"
        self.ips = []  # Cache-elt IP címek

    def connect_to_database(self):
        """Adatbáziskapcsolat létrehozása."""
        try:
            return mysql.connector.connect(**self.db_config)
        except Error as e:
            print(f"Adatbázis hiba: {e}")
            return None

    def fetch_ips(self, connection):
        """IP címek frissítése az adatbázisból."""
        try:
            cursor = connection.cursor()
            cursor.execute("SELECT device_id FROM raspberrydevices")
            return [row[0] for row in cursor.fetchall() if row[0].startswith("10.10.40.")]
        except Error as e:
            print(f"Lekérdezési hiba: {e}")
            return []

    def execute_remote_command(self, ip, command):
        """Parancs végrehajtása SSH-n keresztül időkorláttal."""
        try:
            with paramiko.SSHClient() as client:
                client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                client.connect(ip, username=self.ssh_username, password=self.ssh_password, timeout=10)
                stdin, stdout, stderr = client.exec_command(command, timeout=15)
                exit_status = stdout.channel.recv_exit_status()
                
                if exit_status != 0:
                    error = stderr.read().decode().strip()
                    print(f"Hiba {ip}-n ({exit_status}): {error}")
                else:
                    print(f"Sikeres végrehajtás {ip}-n")
        except Exception as e:
            print(f"SSH hiba {ip}-n: {str(e)}")

    def stop_program(self, ip):
        """Program leállítása egy eszközön."""
        self.execute_remote_command(ip, "killall -9 python3")

    def start_program(self, ip):
        """Program indítása egy eszközön."""
        cmd = f"source {self.virtual_env_path}/bin/activate && nohup python3 {self.script_path} >/dev/null 2>&1 &"
        self.execute_remote_command(ip, cmd)

    def update_ips(self):
        """IP címek frissítése szálban."""
        connection = self.connect_to_database()
        if connection:
            self.ips = self.fetch_ips(connection)
            connection.close()
    


    def generate_excel_reports(self):
        """🔹 Napi és havi Excel riport generálása és elmentése dátum alapú mappába."""
        print("📊 Excel riportok generálása elindult...\n")

        try:
            # 📅 Mai dátum
            today = datetime.now().strftime("%Y-%m-%d")
            year, month = today.split("-")[:2]  # Év és hónap kinyerése

            # 📂 Útvonal a napi riportokhoz
            report_folder = Path(self.report_path) / today
            report_folder.mkdir(parents=True, exist_ok=True)  # Raspberry kompatibilis könyvtár létrehozás

            # 📌 API URL-ek
            api_urls = {
                "daily": f"http://10.10.40.45:5000/api/users_progress_day?date={today}",
                "monthly": f"http://10.10.40.45:5000/api/users_progress_month?year={year}&month={month}"
            }

            # 📌 Letöltési fájlnevek
            filenames = {
                "daily": f"Users_Progress_Day_{today}.xlsx",
                "monthly": f"Users_Progress_Month_{year}-{month}.xlsx"
            }

            # 🔹 Mindkét riport letöltése
            for report_type, url in api_urls.items():
                response = requests.get(url)

                if response.status_code == 200:
                    output_path = report_folder / filenames[report_type]

                    # 🔹 A kapott Excel fájl mentése
                    with output_path.open("wb") as file:
                        file.write(response.content)

                    print(f"✅ {report_type.capitalize()} riport sikeresen mentve: {output_path}")

                    # Ha havi riport, akkor adjunk hozzá diagramokat
                    if report_type == "monthly":
                        self.add_charts_to_excel(output_path)


                else:
                    print(f"⚠️ Hiba az API hívásnál ({report_type}): {response.status_code}, {response.text}")

        except PermissionError:
            print(f"🚨 Nincs jogosultság a {report_folder} létrehozásához!")
        except Exception as e:
            print(f"❌ [ERROR] Excel riport generálás sikertelen: {e}")

        

    def import_excel_to_mariadb(self):
    
        try:
            # Excel fájl beolvasása Pandas segítségével
            df = pd.read_excel(self.excel_file_path, dtype=str)  # Minden adatot szövegként kezelünk
            df = df.fillna("")  # Az összes NaN értéket üres sztringgé alakítjuk

            # MariaDB kapcsolat létrehozása
            connection = self.connect_to_database()
            if connection is None:
                return

            cursor = connection.cursor()

            # Tábla létrehozása, ha nem létezik
            column_definitions = ", ".join([f"`{col}` TEXT" for col in df.columns])
            create_table_query = f"""
            CREATE TABLE IF NOT EXISTS t_dump (
            id INT AUTO_INCREMENT PRIMARY KEY,
            {column_definitions}
        );
            """
            cursor.execute(create_table_query)
            print("A t_dump tábla létrehozva vagy már létezik.")

            # Adatok törlése az `t_dump` táblából
            cursor.execute("TRUNCATE TABLE t_dump;")
            print("A t_dump tábla kiürítve.")

            # Adatok importálása
            columns = ", ".join([f"`{col}`" for col in df.columns])
            placeholders = ", ".join(["%s"] * len(df.columns))
            insert_query = f"INSERT INTO t_dump ({columns}) VALUES ({placeholders})"

            data = [tuple(row) for row in df.values]
        
            cursor.executemany(insert_query, data)
            connection.commit()
            print(f"{cursor.rowcount} sor importálva a t_dump táblába.")

            # Kapcsolat lezárása
            cursor.close()
            connection.close()
            print("Kapcsolat lezárva.")

        except Exception as e:
            print(f"Hiba az Excel importálásakor: {str(e)}")
            
    def add_charts_to_excel(self, file_path):
        """📊 Diagramok hozzáadása a havi riporthoz megfelelő adatformázással."""
        print(f"📈 Diagramok hozzáadása a fájlhoz: {file_path}")

        wb = openpyxl.load_workbook(file_path)

        for sheet in wb.sheetnames:
            ws = wb[sheet]

            # 🔹 Fejlécek keresése
            headers = [cell.value for cell in ws[1]]
            try:
                expected_time_col = headers.index("Elvart ido (H.MM)") + 1
                elapsed_time_col = headers.index("Eltelt ido (H.MM)") + 1
                user_col = headers.index("WO") + 1  # WO oszlop az azonosításhoz
            except ValueError:
                print(f"⚠️ Hiba: Nem található megfelelő oszlop a '{sheet}' munkalapon!")
                continue

            # 🔹 Adattartomány meghatározása
            last_row = ws.max_row

            if last_row < 2:
                print(f"⚠️ Nincs elég adat a '{sheet}' munkalapon diagram készítéséhez!")
                continue

            # **Kikényszerítjük a számformátumot a teljes oszlopra**
            for row in range(2, last_row + 1):
                ws.cell(row=row, column=expected_time_col).value = float(ws.cell(row=row, column=expected_time_col).value or 0)
                ws.cell(row=row, column=elapsed_time_col).value = float(ws.cell(row=row, column=elapsed_time_col).value or 0)

            # 🔹 Diagram adatok
            data_range1 = Reference(ws, min_col=expected_time_col, min_row=1, max_row=last_row)
            data_range2 = Reference(ws, min_col=elapsed_time_col, min_row=1, max_row=last_row)
            categories = Reference(ws, min_col=user_col, min_row=2, max_row=last_row)

            # 🔹 Oszlopdiagram létrehozása
            chart = BarChart()
            chart.title = f"{sheet} - Elvárt vs. Eltelt Idő"
            chart.y_axis.title = "Idő (óra)"
            chart.x_axis.title = "WO"
            chart.y_axis.majorGridlines = None  # Segédvonalak kikapcsolása
            chart.legend.position = "r"  # Jobbra igazított jelmagyarázat

            # 🔹 Adatok hozzáadása a diagramhoz
            chart.add_data(data_range1, titles_from_data=True)
            chart.add_data(data_range2, titles_from_data=True)
            chart.set_categories(categories)

            # 🔹 Színezés
            chart.series[0].graphicalProperties.solidFill = "1F497D"  # Sötétkék - Elvárt idő
            chart.series[1].graphicalProperties.solidFill = "4F6228"  # Sötétzöld - Eltelt idő

            # 🔹 Diagram beillesztése az Excelbe
            chart_location = f"G{last_row + 2}"
            ws.add_chart(chart, chart_location)

        # 📥 Excel fájl mentése diagramokkal együtt
        wb.save(file_path)
        print(f"✅ Diagramok sikeresen hozzáadva: {file_path}")
    


    def convert_dispatch(self):
        file_name = '/mnt/ftp_reports/Administrator_AUTO.PROD.DISPATCH.xls'
        rows = []

        with open(file_name, mode='r', newline='', encoding='latin-1') as file:
            csv_reader = csv.reader(file, delimiter='\t')

            for row in csv_reader:
                rows.append(row)

        df = pd.DataFrame(rows)

        output_file = '/home/user/Desktop/raspberry-monitoring-main/Raspberry monitoring/Administrator_AUTO.PROD.DISPATCH.xlsx'
        df.to_excel(output_file, index=False, header=False)  # header=False: nem rja bele a fejlcet

        print(f"Excel fjl ltrehozva: {output_file}")
        
        

        # Excel fjl betltse (header nlkl)
        df = pd.read_excel('/home/user/Desktop/raspberry-monitoring-main/Raspberry monitoring/Administrator_AUTO.PROD.DISPATCH.xlsx', header=None)

        emi_data = []
        mte_data = []

        # EMI adatok gyujtse (6. sorbl indulva)
        current_row = 5  # 6. sor indexe 0-tl szmolva
        totals_row = None

        # EMI adatok kinyerse
        while current_row < len(df):
            cell_value = df.iloc[current_row, 0]
            if isinstance(cell_value, str) and cell_value.startswith("Totals"):
                totals_row = current_row
                break
            else:
                # A, B, L, N oszlopok (0, 1, 11, 13)
                row_data = df.iloc[current_row, [0, 1, 3, 11, 13]].tolist()
                emi_data.append(row_data)
            current_row += 1
            
        # MTE adatok gyujtse (Totals utni 2. sorbl)
        if totals_row is not None:
            mte_start = totals_row + 2  # Totals utni 2. sor
            current_row = mte_start
            
            # Kvetkezo Totals-ig gyujts
            while current_row < len(df):
                cell_value = df.iloc[current_row, 0]
                if isinstance(cell_value, str) and cell_value.startswith("Totals"):
                    break
                else:
                    row_data = df.iloc[current_row, [0, 1, 3, 11, 13]].tolist()
                    mte_data.append(row_data)
                current_row += 1

        # JSON fjl neve
        json_file_path = "/home/user/Desktop/raspberry-monitoring-main/Raspberry monitoring/static/extracted_data.json"

        # j JSON adatstruktra ltrehozsa
        export_data = {
            "EMI": emi_data,
            "MTE": mte_data
        }

        # JSON fjl mentse (rgi adatok fellrsa)
        with open(json_file_path, "w", encoding="utf-8") as json_file:
            json.dump(export_data, json_file, indent=4, ensure_ascii=False)
            
        print(f"Az adatok sikeresen mentsre kerltek: {json_file_path}")


    def schedule_tasks(self):
        """Fő ütemező ciklus."""
        while True:
            try:
                now = datetime.now()
                
                # IP címek frissítése minden percben
                if now.second == 0:
                    threading.Thread(target=self.update_ips).start()

                # Program leállítás 23:15-kor
                if now.hour == 23 and now.minute == 15:
                    if not self.last_stop_time or self.last_stop_time.date() != now.date():
                        for ip in self.ips:
                            threading.Thread(target=self.stop_program, args=(ip,)).start()
                        self.last_stop_time = now
                
                #Excle users progress export
                if now.hour == 23 and now.minute == 30:
                    if not self.last_report_time or self.last_report_time.date() != now.date():
                        threading.Thread(target=self.generate_excel_reports).start()
                        self.last_report_time = now        
                        
                # Excel importálás 6:00-kor
                if now.hour == 6 and now.minute == 00:
                    if not self.last_import_time or self.last_import_time.date() != now.date():
                        threading.Thread(target=self.import_excel_to_mariadb).start()
                        self.last_import_time = now
                        
                # Excel importálás 6:10-kor
                if now.hour == 6 and now.minute == 10:
                    if not self.last_import_time or self.last_import_time.date() != now.date():
                        threading.Thread(target=self.convert_dispatch).start()
                        self.last_import_time = now         

                # Program indítás 6:55-kor
                if now.hour == 6 and now.minute == 55:
                    if not self.last_start_time or self.last_start_time.date() != now.date():
                        for ip in self.ips:
                            threading.Thread(target=self.start_program, args=(ip,)).start()
                        self.last_start_time = now

                       

                time.sleep(1)

            except Exception as e:
                print(f"Kritikus hiba: {str(e)}")
                time.sleep(60)

if __name__ == "__main__":
    db_config = {
        'host': '10.10.2.15',
        'user': 'root',
        'password': 'admin321',
        'database': 'paperless'
    }
    
    scheduler = RaspberryScheduler(
        db_config=db_config,
        virtual_env_path="/home/user/myenv",
        script_path="/home/user/Desktop/V3.7.py",
        excel_file_path="/mnt/ftp_reports/Administrator_AUTO.ITEM.MASTER.DUMP.xlsx" ,
        report_path="/mnt/exportexcelniko"
    )
    
    scheduler.schedule_tasks()

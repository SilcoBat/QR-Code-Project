import os
import paramiko
import concurrent.futures
import mysql.connector

DB_HOST = "10.10.2.15"
DB_USER = "root"  
DB_PASSWORD = "admin321"  
DB_NAME = "paperless" 

USERNAME = "user"  
PASSWORD = "user"  
NETWORK_PREFIX = "10.10.40"

def get_db_connection():
    return mysql.connector.connect(
        host=DB_HOST,
        user=DB_USER,
        password=DB_PASSWORD,
        database=DB_NAME
    )

def fetch_devices_from_db():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("SELECT device_id, device_name FROM raspberrydevices")
    devices = {row["device_name"]: row["device_id"] for row in cursor.fetchall()}

    cursor.close()
    conn.close()

    return devices  # Pl.: {"RPi-2": "10.10.40.34", "RPi-3": "10.10.40.45"}

def update_ip_in_db(hostname, new_ip):
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("UPDATE raspberrydevices SET device_id = %s WHERE device_name = %s", (new_ip, hostname))
    conn.commit()

    cursor.close()
    conn.close()
    print(f"Updated IP for {hostname} to {new_ip}")

def ping_device(ip):
    response = os.system(f"ping -c 1 -W 1 {ip} > /dev/null 2>&1")
    return response == 0  

def get_raspberry_pi_hostname(ip):
    try:
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(ip, username=USERNAME, password=PASSWORD, timeout=10)

        stdin, stdout, stderr = client.exec_command("hostname")
        hostname = stdout.read().decode().strip()

        stdin, stdout, stderr = client.exec_command("uname -a")
        os_info = stdout.read().decode().strip()

        client.close()

        if "armv7l" in os_info or "aarch64" in os_info:
            return hostname

    except (paramiko.ssh_exception.NoValidConnectionsError, paramiko.ssh_exception.SSHException, Exception):
        return None  

    return None  

def scan_network_and_update_db():
    raspberry_devices = []

    with concurrent.futures.ThreadPoolExecutor(max_workers=50) as executor:
        futures = {executor.submit(ping_device, f"{NETWORK_PREFIX}.{i}"): i for i in range(1, 255)}
        active_ips = [f"{NETWORK_PREFIX}.{i}" for future, i in futures.items() if future.result()]

        ssh_futures = {executor.submit(get_raspberry_pi_hostname, ip): ip for ip in active_ips}
        for future in concurrent.futures.as_completed(ssh_futures):
            ip = ssh_futures[future]
            hostname = future.result()
            if hostname:
                raspberry_devices.append((ip, hostname))

    db_devices = fetch_devices_from_db()

    for ip, hostname in raspberry_devices:
        if hostname in db_devices:
            current_ip = db_devices[hostname]
            if current_ip != ip:  
                update_ip_in_db(hostname, ip)

    return raspberry_devices

if __name__ == "__main__":
    print("Scanning network for Raspberry Pi devices and updating database...")
    rpi_devices = scan_network_and_update_db()

    if rpi_devices:
        print("\nRaspberry Pi devices found and updated in DB:")
        for ip, hostname in rpi_devices:
            print(f"Raspberry Pi at IP: {ip}, Hostname: {hostname}")
    else:
        print("\nNo Raspberry Pi devices found.")

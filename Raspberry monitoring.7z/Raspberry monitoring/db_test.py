# -*- coding: utf-8 -*-

import sqlite3

def fetch_first_record():
    try:
        # Kapcsol�d�s az SQLite adatb�zishoz
        conn = sqlite3.connect('/mnt/sqlite_db/test_db.db')
        cursor = conn.cursor()
        
        # Elso rekord lek�rdez�se a t_dump t�bl�b�l
        cursor.execute("SELECT * FROM t_dump LIMIT 1;")
        first_record = cursor.fetchone()
        
        # Eredm�ny ki�r�sa
        if first_record:
            print("Az elso rekord a t_dump tablaban:", first_record)
        else:
            print("A t_dump tabla ures.")

    except sqlite3.Error as e:
        print("SQLite hiba:", e)
    finally:
        if conn:
            conn.close()

fetch_first_record()
